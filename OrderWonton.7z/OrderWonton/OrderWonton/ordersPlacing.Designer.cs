﻿namespace OrderWonton
{
    partial class ordersPlacing
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.dtp預計取貨日 = new System.Windows.Forms.DateTimePicker();
            this.label12 = new System.Windows.Forms.Label();
            this.lbl訂單日期 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.lbl小計 = new System.Windows.Forms.Label();
            this.cbox取貨方式 = new System.Windows.Forms.ComboBox();
            this.lbl每包數量 = new System.Windows.Forms.Label();
            this.lbl單價 = new System.Windows.Forms.Label();
            this.cbox選擇產品 = new System.Windows.Forms.ComboBox();
            this.cbox客戶 = new System.Windows.Forms.ComboBox();
            this.btn加 = new System.Windows.Forms.Button();
            this.btn減 = new System.Windows.Forms.Button();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.tb數量 = new System.Windows.Forms.TextBox();
            this.tb寄送地址 = new System.Windows.Forms.TextBox();
            this.tb聯絡方式 = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.btn新增 = new System.Windows.Forms.Button();
            this.btn回主頁 = new System.Windows.Forms.Button();
            this.btn關閉 = new System.Windows.Forms.Button();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.LemonChiffon;
            this.panel1.Controls.Add(this.dtp預計取貨日);
            this.panel1.Controls.Add(this.label12);
            this.panel1.Controls.Add(this.lbl訂單日期);
            this.panel1.Controls.Add(this.label13);
            this.panel1.Controls.Add(this.label11);
            this.panel1.Controls.Add(this.label10);
            this.panel1.Controls.Add(this.lbl小計);
            this.panel1.Controls.Add(this.cbox取貨方式);
            this.panel1.Controls.Add(this.lbl每包數量);
            this.panel1.Controls.Add(this.lbl單價);
            this.panel1.Controls.Add(this.cbox選擇產品);
            this.panel1.Controls.Add(this.cbox客戶);
            this.panel1.Controls.Add(this.btn加);
            this.panel1.Controls.Add(this.btn減);
            this.panel1.Controls.Add(this.label9);
            this.panel1.Controls.Add(this.label8);
            this.panel1.Controls.Add(this.label7);
            this.panel1.Controls.Add(this.label6);
            this.panel1.Controls.Add(this.label5);
            this.panel1.Controls.Add(this.tb數量);
            this.panel1.Controls.Add(this.tb寄送地址);
            this.panel1.Controls.Add(this.tb聯絡方式);
            this.panel1.Controls.Add(this.label4);
            this.panel1.Controls.Add(this.label3);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Location = new System.Drawing.Point(51, 33);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(679, 651);
            this.panel1.TabIndex = 6;
            // 
            // dtp預計取貨日
            // 
            this.dtp預計取貨日.Font = new System.Drawing.Font("微軟正黑體", 13.84615F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.dtp預計取貨日.Location = new System.Drawing.Point(203, 418);
            this.dtp預計取貨日.Name = "dtp預計取貨日";
            this.dtp預計取貨日.Size = new System.Drawing.Size(273, 41);
            this.dtp預計取貨日.TabIndex = 28;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("微軟正黑體", 13.84615F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label12.Location = new System.Drawing.Point(34, 418);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(146, 32);
            this.label12.TabIndex = 27;
            this.label12.Text = "預計取貨日:";
            // 
            // lbl訂單日期
            // 
            this.lbl訂單日期.AutoSize = true;
            this.lbl訂單日期.Font = new System.Drawing.Font("微軟正黑體", 13.84615F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.lbl訂單日期.Location = new System.Drawing.Point(197, 14);
            this.lbl訂單日期.Name = "lbl訂單日期";
            this.lbl訂單日期.Size = new System.Drawing.Size(26, 32);
            this.lbl訂單日期.TabIndex = 26;
            this.lbl訂單日期.Text = "-";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("微軟正黑體", 13.84615F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label13.Location = new System.Drawing.Point(59, 14);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(121, 32);
            this.label13.TabIndex = 25;
            this.label13.Text = "訂單日期:";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("微軟正黑體", 13.84615F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label11.ForeColor = System.Drawing.Color.Black;
            this.label11.Location = new System.Drawing.Point(295, 601);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(46, 32);
            this.label11.TabIndex = 23;
            this.label11.Text = "元 ";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("微軟正黑體", 13.84615F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label10.ForeColor = System.Drawing.Color.Black;
            this.label10.Location = new System.Drawing.Point(278, 189);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(46, 32);
            this.label10.TabIndex = 22;
            this.label10.Text = "元 ";
            // 
            // lbl小計
            // 
            this.lbl小計.AutoSize = true;
            this.lbl小計.Font = new System.Drawing.Font("微軟正黑體", 13.84615F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.lbl小計.ForeColor = System.Drawing.Color.Red;
            this.lbl小計.Location = new System.Drawing.Point(204, 601);
            this.lbl小計.Name = "lbl小計";
            this.lbl小計.Size = new System.Drawing.Size(26, 32);
            this.lbl小計.TabIndex = 21;
            this.lbl小計.Text = "-";
            // 
            // cbox取貨方式
            // 
            this.cbox取貨方式.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbox取貨方式.Font = new System.Drawing.Font("微軟正黑體", 13.84615F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.cbox取貨方式.FormattingEnabled = true;
            this.cbox取貨方式.Items.AddRange(new object[] {
            "現場取貨",
            "郵遞配送"});
            this.cbox取貨方式.Location = new System.Drawing.Point(203, 365);
            this.cbox取貨方式.Name = "cbox取貨方式";
            this.cbox取貨方式.Size = new System.Drawing.Size(273, 40);
            this.cbox取貨方式.TabIndex = 20;
            // 
            // lbl每包數量
            // 
            this.lbl每包數量.AutoSize = true;
            this.lbl每包數量.Font = new System.Drawing.Font("微軟正黑體", 13.84615F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.lbl每包數量.Location = new System.Drawing.Point(209, 250);
            this.lbl每包數量.Name = "lbl每包數量";
            this.lbl每包數量.Size = new System.Drawing.Size(115, 32);
            this.lbl每包數量.TabIndex = 19;
            this.lbl每包數量.Text = "每包數量";
            // 
            // lbl單價
            // 
            this.lbl單價.AutoSize = true;
            this.lbl單價.Font = new System.Drawing.Font("微軟正黑體", 13.84615F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.lbl單價.ForeColor = System.Drawing.Color.Red;
            this.lbl單價.Location = new System.Drawing.Point(209, 189);
            this.lbl單價.Name = "lbl單價";
            this.lbl單價.Size = new System.Drawing.Size(26, 32);
            this.lbl單價.TabIndex = 18;
            this.lbl單價.Text = "-";
            // 
            // cbox選擇產品
            // 
            this.cbox選擇產品.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbox選擇產品.Font = new System.Drawing.Font("微軟正黑體", 13.84615F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.cbox選擇產品.FormattingEnabled = true;
            this.cbox選擇產品.Location = new System.Drawing.Point(203, 127);
            this.cbox選擇產品.Name = "cbox選擇產品";
            this.cbox選擇產品.Size = new System.Drawing.Size(273, 40);
            this.cbox選擇產品.TabIndex = 17;
            this.cbox選擇產品.SelectedIndexChanged += new System.EventHandler(this.cbox選擇產品_SelectedIndexChanged);
            // 
            // cbox客戶
            // 
            this.cbox客戶.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbox客戶.Font = new System.Drawing.Font("微軟正黑體", 13.84615F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.cbox客戶.FormattingEnabled = true;
            this.cbox客戶.Location = new System.Drawing.Point(203, 72);
            this.cbox客戶.Name = "cbox客戶";
            this.cbox客戶.Size = new System.Drawing.Size(273, 40);
            this.cbox客戶.TabIndex = 16;
            this.cbox客戶.SelectedIndexChanged += new System.EventHandler(this.cbox客戶_SelectedIndexChanged);
            // 
            // btn加
            // 
            this.btn加.BackColor = System.Drawing.Color.Khaki;
            this.btn加.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn加.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btn加.Font = new System.Drawing.Font("微軟正黑體", 13.84615F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.btn加.Image = global::OrderWonton.Properties.Resources.plus_216373;
            this.btn加.Location = new System.Drawing.Point(438, 306);
            this.btn加.Name = "btn加";
            this.btn加.Size = new System.Drawing.Size(60, 40);
            this.btn加.TabIndex = 15;
            this.btn加.UseVisualStyleBackColor = false;
            this.btn加.Click += new System.EventHandler(this.btn加_Click);
            // 
            // btn減
            // 
            this.btn減.BackColor = System.Drawing.Color.Khaki;
            this.btn減.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn減.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btn減.Font = new System.Drawing.Font("微軟正黑體", 13.84615F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.btn減.Image = global::OrderWonton.Properties.Resources.minus_round_211863;
            this.btn減.Location = new System.Drawing.Point(235, 306);
            this.btn減.Name = "btn減";
            this.btn減.Size = new System.Drawing.Size(60, 40);
            this.btn減.TabIndex = 14;
            this.btn減.UseVisualStyleBackColor = false;
            this.btn減.Click += new System.EventHandler(this.btn減_Click);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("微軟正黑體", 13.84615F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label9.Location = new System.Drawing.Point(109, 601);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(71, 32);
            this.label9.TabIndex = 13;
            this.label9.Text = "小計:";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("微軟正黑體", 13.84615F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label8.Location = new System.Drawing.Point(59, 544);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(121, 32);
            this.label8.TabIndex = 12;
            this.label8.Text = "寄送地址:";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("微軟正黑體", 13.84615F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label7.Location = new System.Drawing.Point(59, 487);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(121, 32);
            this.label7.TabIndex = 11;
            this.label7.Text = "聯絡方式:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("微軟正黑體", 13.84615F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label6.Location = new System.Drawing.Point(59, 365);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(121, 32);
            this.label6.TabIndex = 10;
            this.label6.Text = "取貨方式:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("微軟正黑體", 13.84615F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label5.Location = new System.Drawing.Point(109, 314);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(71, 32);
            this.label5.TabIndex = 9;
            this.label5.Text = "數量:";
            // 
            // tb數量
            // 
            this.tb數量.Font = new System.Drawing.Font("微軟正黑體", 13.84615F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.tb數量.Location = new System.Drawing.Point(321, 305);
            this.tb數量.Name = "tb數量";
            this.tb數量.ReadOnly = true;
            this.tb數量.Size = new System.Drawing.Size(93, 41);
            this.tb數量.TabIndex = 8;
            this.tb數量.TextChanged += new System.EventHandler(this.tb數量_TextChanged);
            // 
            // tb寄送地址
            // 
            this.tb寄送地址.Font = new System.Drawing.Font("微軟正黑體", 13.84615F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.tb寄送地址.Location = new System.Drawing.Point(203, 541);
            this.tb寄送地址.Name = "tb寄送地址";
            this.tb寄送地址.ReadOnly = true;
            this.tb寄送地址.Size = new System.Drawing.Size(377, 41);
            this.tb寄送地址.TabIndex = 7;
            // 
            // tb聯絡方式
            // 
            this.tb聯絡方式.Font = new System.Drawing.Font("微軟正黑體", 13.84615F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.tb聯絡方式.Location = new System.Drawing.Point(203, 478);
            this.tb聯絡方式.Name = "tb聯絡方式";
            this.tb聯絡方式.ReadOnly = true;
            this.tb聯絡方式.Size = new System.Drawing.Size(273, 41);
            this.tb聯絡方式.TabIndex = 6;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("微軟正黑體", 13.84615F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label4.Location = new System.Drawing.Point(109, 250);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(71, 32);
            this.label4.TabIndex = 3;
            this.label4.Text = "規格:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("微軟正黑體", 13.84615F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label3.Location = new System.Drawing.Point(109, 189);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(71, 32);
            this.label3.TabIndex = 2;
            this.label3.Text = "單價:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("微軟正黑體", 13.84615F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label2.Location = new System.Drawing.Point(59, 130);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(121, 32);
            this.label2.TabIndex = 1;
            this.label2.Text = "選擇產品:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("微軟正黑體", 13.84615F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label1.Location = new System.Drawing.Point(109, 72);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(71, 32);
            this.label1.TabIndex = 0;
            this.label1.Text = "客戶:";
            // 
            // btn新增
            // 
            this.btn新增.BackColor = System.Drawing.Color.Khaki;
            this.btn新增.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn新增.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btn新增.Font = new System.Drawing.Font("微軟正黑體", 13.84615F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.btn新增.Location = new System.Drawing.Point(147, 705);
            this.btn新增.Name = "btn新增";
            this.btn新增.Size = new System.Drawing.Size(154, 54);
            this.btn新增.TabIndex = 13;
            this.btn新增.Text = "新增";
            this.btn新增.UseVisualStyleBackColor = false;
            this.btn新增.Click += new System.EventHandler(this.btn新增_Click);
            // 
            // btn回主頁
            // 
            this.btn回主頁.BackColor = System.Drawing.Color.Goldenrod;
            this.btn回主頁.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn回主頁.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btn回主頁.Font = new System.Drawing.Font("微軟正黑體", 13.84615F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.btn回主頁.Location = new System.Drawing.Point(452, 705);
            this.btn回主頁.Name = "btn回主頁";
            this.btn回主頁.Size = new System.Drawing.Size(161, 54);
            this.btn回主頁.TabIndex = 14;
            this.btn回主頁.Text = "回主頁";
            this.btn回主頁.UseVisualStyleBackColor = false;
            this.btn回主頁.Click += new System.EventHandler(this.btn回主頁_Click);
            // 
            // btn關閉
            // 
            this.btn關閉.BackColor = System.Drawing.Color.LightCoral;
            this.btn關閉.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn關閉.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btn關閉.Font = new System.Drawing.Font("微軟正黑體", 13.84615F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.btn關閉.Image = global::OrderWonton.Properties.Resources.exit2;
            this.btn關閉.Location = new System.Drawing.Point(758, 2);
            this.btn關閉.Margin = new System.Windows.Forms.Padding(4);
            this.btn關閉.Name = "btn關閉";
            this.btn關閉.Size = new System.Drawing.Size(34, 31);
            this.btn關閉.TabIndex = 24;
            this.btn關閉.UseVisualStyleBackColor = false;
            this.btn關閉.Click += new System.EventHandler(this.btn關閉_Click);
            // 
            // ordersPlacing
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.Highlight;
            this.ClientSize = new System.Drawing.Size(794, 780);
            this.Controls.Add(this.btn關閉);
            this.Controls.Add(this.btn回主頁);
            this.Controls.Add(this.btn新增);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "ordersPlacing";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "新增訂單";
            this.Load += new System.EventHandler(this.ordersPlacing_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox tb數量;
        private System.Windows.Forms.TextBox tb寄送地址;
        private System.Windows.Forms.TextBox tb聯絡方式;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button btn減;
        private System.Windows.Forms.Label lbl小計;
        private System.Windows.Forms.ComboBox cbox取貨方式;
        private System.Windows.Forms.Label lbl每包數量;
        private System.Windows.Forms.Label lbl單價;
        private System.Windows.Forms.ComboBox cbox選擇產品;
        private System.Windows.Forms.ComboBox cbox客戶;
        private System.Windows.Forms.Button btn加;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button btn新增;
        private System.Windows.Forms.Button btn回主頁;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label lbl訂單日期;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.DateTimePicker dtp預計取貨日;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Button btn關閉;
    }
}