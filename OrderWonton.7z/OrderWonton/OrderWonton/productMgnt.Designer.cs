﻿namespace OrderWonton
{
    partial class productMgnt
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btn所有產品 = new System.Windows.Forms.Button();
            this.lbox產品 = new System.Windows.Forms.ListBox();
            this.tb查詢 = new System.Windows.Forms.TextBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.btn上傳 = new System.Windows.Forms.Button();
            this.btn選擇圖片 = new System.Windows.Forms.Button();
            this.pictureBox上傳 = new System.Windows.Forms.PictureBox();
            this.tb產品編號 = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.chk狀態 = new System.Windows.Forms.CheckBox();
            this.tb價格 = new System.Windows.Forms.TextBox();
            this.tb規格 = new System.Windows.Forms.TextBox();
            this.tb品名 = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.btn新增 = new System.Windows.Forms.Button();
            this.btn修改 = new System.Windows.Forms.Button();
            this.btn刪除 = new System.Windows.Forms.Button();
            this.btn回主頁 = new System.Windows.Forms.Button();
            this.btn關閉 = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.btn查詢 = new System.Windows.Forms.Button();
            this.openFileDialog = new System.Windows.Forms.OpenFileDialog();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox上傳)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // btn所有產品
            // 
            this.btn所有產品.BackColor = System.Drawing.Color.Khaki;
            this.btn所有產品.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn所有產品.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btn所有產品.Font = new System.Drawing.Font("微軟正黑體", 13.84615F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.btn所有產品.Location = new System.Drawing.Point(39, 105);
            this.btn所有產品.Name = "btn所有產品";
            this.btn所有產品.Size = new System.Drawing.Size(189, 44);
            this.btn所有產品.TabIndex = 1;
            this.btn所有產品.Text = "所有產品";
            this.btn所有產品.UseVisualStyleBackColor = false;
            this.btn所有產品.Click += new System.EventHandler(this.btn所有產品_Click);
            // 
            // lbox產品
            // 
            this.lbox產品.BackColor = System.Drawing.Color.LemonChiffon;
            this.lbox產品.Font = new System.Drawing.Font("微軟正黑體", 13.84615F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.lbox產品.FormattingEnabled = true;
            this.lbox產品.ItemHeight = 32;
            this.lbox產品.Location = new System.Drawing.Point(39, 169);
            this.lbox產品.Name = "lbox產品";
            this.lbox產品.Size = new System.Drawing.Size(189, 452);
            this.lbox產品.TabIndex = 2;
            this.lbox產品.SelectedIndexChanged += new System.EventHandler(this.lbox產品_SelectedIndexChanged);
            // 
            // tb查詢
            // 
            this.tb查詢.Font = new System.Drawing.Font("微軟正黑體", 13.84615F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.tb查詢.Location = new System.Drawing.Point(265, 30);
            this.tb查詢.Name = "tb查詢";
            this.tb查詢.Size = new System.Drawing.Size(264, 41);
            this.tb查詢.TabIndex = 3;
            this.tb查詢.Text = "請輸入產品查詢";
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.LemonChiffon;
            this.panel1.Controls.Add(this.btn上傳);
            this.panel1.Controls.Add(this.btn選擇圖片);
            this.panel1.Controls.Add(this.pictureBox上傳);
            this.panel1.Controls.Add(this.tb產品編號);
            this.panel1.Controls.Add(this.label5);
            this.panel1.Controls.Add(this.chk狀態);
            this.panel1.Controls.Add(this.tb價格);
            this.panel1.Controls.Add(this.tb規格);
            this.panel1.Controls.Add(this.tb品名);
            this.panel1.Controls.Add(this.label4);
            this.panel1.Controls.Add(this.label3);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Location = new System.Drawing.Point(265, 105);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(553, 516);
            this.panel1.TabIndex = 5;
            // 
            // btn上傳
            // 
            this.btn上傳.BackColor = System.Drawing.Color.Khaki;
            this.btn上傳.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn上傳.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btn上傳.Font = new System.Drawing.Font("微軟正黑體", 13.84615F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.btn上傳.Location = new System.Drawing.Point(389, 450);
            this.btn上傳.Name = "btn上傳";
            this.btn上傳.Size = new System.Drawing.Size(85, 41);
            this.btn上傳.TabIndex = 25;
            this.btn上傳.Text = "上傳";
            this.btn上傳.UseVisualStyleBackColor = false;
            this.btn上傳.Click += new System.EventHandler(this.btn上傳_Click);
            // 
            // btn選擇圖片
            // 
            this.btn選擇圖片.BackColor = System.Drawing.Color.Khaki;
            this.btn選擇圖片.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn選擇圖片.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btn選擇圖片.Font = new System.Drawing.Font("微軟正黑體", 13.84615F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.btn選擇圖片.Location = new System.Drawing.Point(266, 450);
            this.btn選擇圖片.Name = "btn選擇圖片";
            this.btn選擇圖片.Size = new System.Drawing.Size(85, 41);
            this.btn選擇圖片.TabIndex = 24;
            this.btn選擇圖片.Text = "選圖";
            this.btn選擇圖片.UseVisualStyleBackColor = false;
            this.btn選擇圖片.Click += new System.EventHandler(this.btn選擇圖片_Click);
            // 
            // pictureBox上傳
            // 
            this.pictureBox上傳.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pictureBox上傳.Cursor = System.Windows.Forms.Cursors.Cross;
            this.pictureBox上傳.Location = new System.Drawing.Point(77, 355);
            this.pictureBox上傳.Name = "pictureBox上傳";
            this.pictureBox上傳.Size = new System.Drawing.Size(152, 136);
            this.pictureBox上傳.TabIndex = 13;
            this.pictureBox上傳.TabStop = false;
            // 
            // tb產品編號
            // 
            this.tb產品編號.Font = new System.Drawing.Font("微軟正黑體", 13.84615F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.tb產品編號.Location = new System.Drawing.Point(168, 33);
            this.tb產品編號.Name = "tb產品編號";
            this.tb產品編號.ReadOnly = true;
            this.tb產品編號.Size = new System.Drawing.Size(250, 41);
            this.tb產品編號.TabIndex = 12;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("微軟正黑體", 13.84615F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label5.Location = new System.Drawing.Point(25, 42);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(114, 32);
            this.label5.TabIndex = 11;
            this.label5.Text = "產品 No.";
            // 
            // chk狀態
            // 
            this.chk狀態.AutoSize = true;
            this.chk狀態.Font = new System.Drawing.Font("微軟正黑體", 13.84615F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.chk狀態.Location = new System.Drawing.Point(168, 285);
            this.chk狀態.Name = "chk狀態";
            this.chk狀態.Size = new System.Drawing.Size(162, 36);
            this.chk狀態.TabIndex = 10;
            this.chk狀態.Text = "現正銷售中";
            this.chk狀態.UseVisualStyleBackColor = true;
            // 
            // tb價格
            // 
            this.tb價格.Font = new System.Drawing.Font("微軟正黑體", 13.84615F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.tb價格.Location = new System.Drawing.Point(168, 218);
            this.tb價格.Name = "tb價格";
            this.tb價格.Size = new System.Drawing.Size(250, 41);
            this.tb價格.TabIndex = 8;
            // 
            // tb規格
            // 
            this.tb規格.Font = new System.Drawing.Font("微軟正黑體", 13.84615F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.tb規格.Location = new System.Drawing.Point(168, 159);
            this.tb規格.Name = "tb規格";
            this.tb規格.Size = new System.Drawing.Size(250, 41);
            this.tb規格.TabIndex = 7;
            // 
            // tb品名
            // 
            this.tb品名.Font = new System.Drawing.Font("微軟正黑體", 13.84615F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.tb品名.Location = new System.Drawing.Point(168, 98);
            this.tb品名.Name = "tb品名";
            this.tb品名.Size = new System.Drawing.Size(250, 41);
            this.tb品名.TabIndex = 6;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("微軟正黑體", 13.84615F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label4.Location = new System.Drawing.Point(71, 285);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(77, 32);
            this.label4.TabIndex = 3;
            this.label4.Text = "狀態: ";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("微軟正黑體", 13.84615F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label3.Location = new System.Drawing.Point(71, 218);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(77, 32);
            this.label3.TabIndex = 2;
            this.label3.Text = "價格: ";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("微軟正黑體", 13.84615F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label2.Location = new System.Drawing.Point(71, 159);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(77, 32);
            this.label2.TabIndex = 1;
            this.label2.Text = "規格: ";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("微軟正黑體", 13.84615F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label1.Location = new System.Drawing.Point(71, 101);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(77, 32);
            this.label1.TabIndex = 0;
            this.label1.Text = "品名: ";
            // 
            // btn新增
            // 
            this.btn新增.BackColor = System.Drawing.Color.Khaki;
            this.btn新增.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn新增.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btn新增.Font = new System.Drawing.Font("微軟正黑體", 13.84615F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.btn新增.Location = new System.Drawing.Point(278, 661);
            this.btn新增.Name = "btn新增";
            this.btn新增.Size = new System.Drawing.Size(152, 58);
            this.btn新增.TabIndex = 6;
            this.btn新增.Text = "新增產品";
            this.btn新增.UseVisualStyleBackColor = false;
            this.btn新增.Click += new System.EventHandler(this.btn新增_Click);
            // 
            // btn修改
            // 
            this.btn修改.BackColor = System.Drawing.Color.Khaki;
            this.btn修改.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn修改.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btn修改.Font = new System.Drawing.Font("微軟正黑體", 13.84615F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.btn修改.Location = new System.Drawing.Point(464, 659);
            this.btn修改.Name = "btn修改";
            this.btn修改.Size = new System.Drawing.Size(152, 60);
            this.btn修改.TabIndex = 10;
            this.btn修改.Text = "修改";
            this.btn修改.UseVisualStyleBackColor = false;
            this.btn修改.Click += new System.EventHandler(this.btn修改_Click);
            // 
            // btn刪除
            // 
            this.btn刪除.BackColor = System.Drawing.Color.Khaki;
            this.btn刪除.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn刪除.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btn刪除.Font = new System.Drawing.Font("微軟正黑體", 13.84615F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.btn刪除.Location = new System.Drawing.Point(654, 659);
            this.btn刪除.Name = "btn刪除";
            this.btn刪除.Size = new System.Drawing.Size(152, 58);
            this.btn刪除.TabIndex = 8;
            this.btn刪除.Text = "刪除";
            this.btn刪除.UseVisualStyleBackColor = false;
            this.btn刪除.Click += new System.EventHandler(this.btn刪除_Click);
            // 
            // btn回主頁
            // 
            this.btn回主頁.BackColor = System.Drawing.Color.Goldenrod;
            this.btn回主頁.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn回主頁.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btn回主頁.Font = new System.Drawing.Font("微軟正黑體", 13.84615F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.btn回主頁.Location = new System.Drawing.Point(58, 661);
            this.btn回主頁.Name = "btn回主頁";
            this.btn回主頁.Size = new System.Drawing.Size(149, 58);
            this.btn回主頁.TabIndex = 15;
            this.btn回主頁.Text = "回主頁";
            this.btn回主頁.UseVisualStyleBackColor = false;
            this.btn回主頁.Click += new System.EventHandler(this.btn回主頁_Click);
            // 
            // btn關閉
            // 
            this.btn關閉.BackColor = System.Drawing.Color.LightCoral;
            this.btn關閉.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn關閉.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btn關閉.Font = new System.Drawing.Font("微軟正黑體", 13.84615F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.btn關閉.Image = global::OrderWonton.Properties.Resources.exit1;
            this.btn關閉.Location = new System.Drawing.Point(824, 0);
            this.btn關閉.Margin = new System.Windows.Forms.Padding(4);
            this.btn關閉.Name = "btn關閉";
            this.btn關閉.Size = new System.Drawing.Size(34, 31);
            this.btn關閉.TabIndex = 23;
            this.btn關閉.UseVisualStyleBackColor = false;
            this.btn關閉.Click += new System.EventHandler(this.btn關閉_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pictureBox1.Image = global::OrderWonton.Properties.Resources.if_Food_C204_2427850;
            this.pictureBox1.Location = new System.Drawing.Point(85, 12);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(90, 84);
            this.pictureBox1.TabIndex = 12;
            this.pictureBox1.TabStop = false;
            // 
            // btn查詢
            // 
            this.btn查詢.BackColor = System.Drawing.Color.Khaki;
            this.btn查詢.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn查詢.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btn查詢.Font = new System.Drawing.Font("微軟正黑體", 13.84615F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.btn查詢.Image = global::OrderWonton.Properties.Resources.if_Magnifier_728952;
            this.btn查詢.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn查詢.Location = new System.Drawing.Point(562, 27);
            this.btn查詢.Name = "btn查詢";
            this.btn查詢.Size = new System.Drawing.Size(133, 49);
            this.btn查詢.TabIndex = 4;
            this.btn查詢.Text = "查詢";
            this.btn查詢.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btn查詢.UseVisualStyleBackColor = false;
            this.btn查詢.Click += new System.EventHandler(this.btn查詢_Click);
            // 
            // openFileDialog
            // 
            this.openFileDialog.FileName = "openFileDialog1";
            // 
            // productMgnt
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.Highlight;
            this.ClientSize = new System.Drawing.Size(860, 761);
            this.Controls.Add(this.btn關閉);
            this.Controls.Add(this.btn回主頁);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.btn查詢);
            this.Controls.Add(this.tb查詢);
            this.Controls.Add(this.btn修改);
            this.Controls.Add(this.btn刪除);
            this.Controls.Add(this.btn新增);
            this.Controls.Add(this.lbox產品);
            this.Controls.Add(this.btn所有產品);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "productMgnt";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "產品資料維護";
            this.Load += new System.EventHandler(this.productMgnt_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox上傳)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btn所有產品;
        private System.Windows.Forms.ListBox lbox產品;
        private System.Windows.Forms.TextBox tb查詢;
        private System.Windows.Forms.Button btn查詢;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox tb價格;
        private System.Windows.Forms.TextBox tb規格;
        private System.Windows.Forms.TextBox tb品名;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button btn新增;
        private System.Windows.Forms.Button btn刪除;
        private System.Windows.Forms.Button btn修改;
        private System.Windows.Forms.CheckBox chk狀態;
        private System.Windows.Forms.TextBox tb產品編號;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Button btn回主頁;
        private System.Windows.Forms.Button btn關閉;
        private System.Windows.Forms.Button btn上傳;
        private System.Windows.Forms.Button btn選擇圖片;
        private System.Windows.Forms.PictureBox pictureBox上傳;
        private System.Windows.Forms.OpenFileDialog openFileDialog;
    }
}