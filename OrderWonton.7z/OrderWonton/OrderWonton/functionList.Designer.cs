﻿namespace OrderWonton
{
    partial class functionList
    {
        /// <summary>
        /// 設計工具所需的變數。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清除任何使用中的資源。
        /// </summary>
        /// <param name="disposing">如果應該處置受控資源則為 true，否則為 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 設計工具產生的程式碼

        /// <summary>
        /// 此為設計工具支援所需的方法 - 請勿使用程式碼編輯器修改
        /// 這個方法的內容。
        /// </summary>
        private void InitializeComponent()
        {
            this.btn新增訂單 = new System.Windows.Forms.Button();
            this.btn營運分析 = new System.Windows.Forms.Button();
            this.btn產品維護 = new System.Windows.Forms.Button();
            this.btn客戶維護 = new System.Windows.Forms.Button();
            this.btn訂單管理 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btn新增訂單
            // 
            this.btn新增訂單.BackColor = System.Drawing.Color.Khaki;
            this.btn新增訂單.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn新增訂單.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btn新增訂單.Font = new System.Drawing.Font("微軟正黑體", 16.06154F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.btn新增訂單.Image = global::OrderWonton.Properties.Resources.order_2639879;
            this.btn新增訂單.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn新增訂單.Location = new System.Drawing.Point(78, 25);
            this.btn新增訂單.Name = "btn新增訂單";
            this.btn新增訂單.Size = new System.Drawing.Size(261, 79);
            this.btn新增訂單.TabIndex = 4;
            this.btn新增訂單.Text = "新增訂單";
            this.btn新增訂單.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btn新增訂單.UseVisualStyleBackColor = false;
            this.btn新增訂單.Click += new System.EventHandler(this.btn新增訂單_Click);
            // 
            // btn營運分析
            // 
            this.btn營運分析.BackColor = System.Drawing.Color.Khaki;
            this.btn營運分析.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn營運分析.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btn營運分析.Font = new System.Drawing.Font("微軟正黑體", 16.06154F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.btn營運分析.Image = global::OrderWonton.Properties.Resources.Analysis_2529943;
            this.btn營運分析.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn營運分析.Location = new System.Drawing.Point(78, 505);
            this.btn營運分析.Name = "btn營運分析";
            this.btn營運分析.Size = new System.Drawing.Size(261, 79);
            this.btn營運分析.TabIndex = 3;
            this.btn營運分析.Text = "營運分析";
            this.btn營運分析.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btn營運分析.UseVisualStyleBackColor = false;
            this.btn營運分析.Click += new System.EventHandler(this.btn營運分析_Click);
            // 
            // btn產品維護
            // 
            this.btn產品維護.BackColor = System.Drawing.Color.Khaki;
            this.btn產品維護.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn產品維護.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btn產品維護.Font = new System.Drawing.Font("微軟正黑體", 16.06154F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.btn產品維護.Image = global::OrderWonton.Properties.Resources.if_restaurant_12_3078511;
            this.btn產品維護.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn產品維護.Location = new System.Drawing.Point(78, 386);
            this.btn產品維護.Name = "btn產品維護";
            this.btn產品維護.Size = new System.Drawing.Size(261, 79);
            this.btn產品維護.TabIndex = 2;
            this.btn產品維護.Text = "產品維護";
            this.btn產品維護.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btn產品維護.UseVisualStyleBackColor = false;
            this.btn產品維護.Click += new System.EventHandler(this.btn產品維護_Click);
            // 
            // btn客戶維護
            // 
            this.btn客戶維護.BackColor = System.Drawing.Color.Khaki;
            this.btn客戶維護.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn客戶維護.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btn客戶維護.Font = new System.Drawing.Font("微軟正黑體", 16.06154F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.btn客戶維護.Image = global::OrderWonton.Properties.Resources.customers2;
            this.btn客戶維護.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn客戶維護.Location = new System.Drawing.Point(78, 260);
            this.btn客戶維護.Name = "btn客戶維護";
            this.btn客戶維護.Size = new System.Drawing.Size(261, 83);
            this.btn客戶維護.TabIndex = 1;
            this.btn客戶維護.Text = "客戶維護";
            this.btn客戶維護.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btn客戶維護.UseVisualStyleBackColor = false;
            this.btn客戶維護.Click += new System.EventHandler(this.btn客戶維護_Click);
            // 
            // btn訂單管理
            // 
            this.btn訂單管理.BackColor = System.Drawing.Color.Khaki;
            this.btn訂單管理.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn訂單管理.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btn訂單管理.Font = new System.Drawing.Font("微軟正黑體", 16.06154F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.btn訂單管理.Image = global::OrderWonton.Properties.Resources.choice3;
            this.btn訂單管理.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn訂單管理.Location = new System.Drawing.Point(78, 139);
            this.btn訂單管理.Name = "btn訂單管理";
            this.btn訂單管理.Size = new System.Drawing.Size(261, 79);
            this.btn訂單管理.TabIndex = 0;
            this.btn訂單管理.Text = "訂單管理";
            this.btn訂單管理.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btn訂單管理.UseVisualStyleBackColor = false;
            this.btn訂單管理.Click += new System.EventHandler(this.btn訂單管理_Click);
            // 
            // functionList
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.Highlight;
            this.ClientSize = new System.Drawing.Size(428, 613);
            this.Controls.Add(this.btn新增訂單);
            this.Controls.Add(this.btn營運分析);
            this.Controls.Add(this.btn產品維護);
            this.Controls.Add(this.btn客戶維護);
            this.Controls.Add(this.btn訂單管理);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "functionList";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "系統功能選擇單";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btn訂單管理;
        private System.Windows.Forms.Button btn客戶維護;
        private System.Windows.Forms.Button btn產品維護;
        private System.Windows.Forms.Button btn營運分析;
        private System.Windows.Forms.Button btn新增訂單;
    }
}

