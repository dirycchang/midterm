﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace OrderWonton
{
    public partial class logo : Form
    {
        public logo()
        {
            InitializeComponent();
        }

        private void logo_Load(object sender, EventArgs e)
        {
            Thread a = new Thread(new ThreadStart(CloseAfterSce));
            a.Start();
        }

        public void CloseAfterSce()
        {
            Form.CheckForIllegalCrossThreadCalls = false;//必寫 原因待查

            //漸漸顯示登入畫面
            this.Opacity = 1.00;//透明度
            while (this.Opacity != 0.00)
            {
                this.Opacity -= 0.00065;
                this.Refresh();
            }

            Thread.Sleep(10);//註: Sleep(1000) 為一秒  故 Sleep(100)為0.1秒 以此類推
            this.Close();
        }
    }
}
