﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.IO;
using System.Windows.Forms;

namespace OrderWonton
{
    public partial class productMgnt : Form
    {
        SqlConnectionStringBuilder scsb;

        public productMgnt()
        {
            InitializeComponent();
        }

        private void productMgnt_Load(object sender, EventArgs e)
        {
            tb查詢.Select();
            using (SqlConnection con = new SqlConnection(Global.scsb))
            {
                con.Open();

                string strSQL = "select p_name from products";
                SqlDataAdapter sqlDataAdapter = new SqlDataAdapter(strSQL, con);
                DataSet ds1 = new DataSet();
                sqlDataAdapter.Fill(ds1, "productName");

                for (int i = 0; i < ds1.Tables["productName"].Rows.Count; i += 1)
                {
                    lbox產品.Items.Add(ds1.Tables["productName"].Rows[i][0]);
                }

                
            }
        }

        
        private void lbox產品_SelectedIndexChanged(object sender, EventArgs e)
        {
            string strSearchName = lbox產品.SelectedItem.ToString();

            using (SqlConnection con = new SqlConnection(Global.scsb))
            {
                con.Open();
                if (strSearchName.Length > 0)
                {
                    string strSQL = "select*from products where p_name like @SearchName";
                    SqlCommand cmd = new SqlCommand(strSQL, con);
                    cmd.Parameters.AddWithValue("@SearchName", "%" + strSearchName + "%");
                    SqlDataReader reader = cmd.ExecuteReader();

                    if (reader.Read() == true)
                    {
                        tb產品編號.Text= string.Format("{0}", reader["p_id"]);
                        tb品名.Text = string.Format("{0}", reader["p_name"]);                        
                        tb規格.Text = string.Format("{0}", reader["p_spec"]);
                        tb價格.Text = string.Format("{0}", reader["p_price"]);
                        chk狀態.Checked = (bool)reader["p_status"];
                    }
                    else
                    {
                        MessageBox.Show("查無此產品");
                        tb產品編號.Text = "";
                        tb品名.Text = "";
                        tb規格.Text = "";
                        tb價格.Text = "";
                        chk狀態.Checked = false;                        
                    }
                }
                else
                {
                    MessageBox.Show("查無此產品");
                }

                //顯示圖片
                using (SqlConnection con2 = new SqlConnection(Global.scsb))
                {                    
                    string strSQL2 = "select p_image from products where p_name = '" + lbox產品.Text + "'";
                    SqlDataAdapter sqlDataAdapter2 = new SqlDataAdapter(strSQL2, con2);
                    DataSet ds2 = new DataSet();
                    sqlDataAdapter2.Fill(ds2, "productimage");
                    try
                    {
                        byte[] Bytes = (byte[])ds2.Tables["productimage"].Rows[0][0];
                        pictureBox上傳.Image = Image.FromStream(new MemoryStream(Bytes));
                    }
                    catch
                    {
                        pictureBox上傳.Image = null;
                    }
                }

                

            }
        }

        private void btn查詢_Click(object sender, EventArgs e)
        {
            lbox產品.Items.Clear();
            using (SqlConnection con = new SqlConnection(Global.scsb))
            {
                con.Open();

                if (tb查詢.Text.Length > 0)
                {
                    string strSQL = "select*from products where p_name like '%" + tb查詢.Text + "%'";
                    DataSet ds1 = new DataSet();
                    SqlDataAdapter sqlDataAdapter = new SqlDataAdapter(strSQL, con);
                    sqlDataAdapter.Fill(ds1, "name");

                    for (int i = 0; i < ds1.Tables["name"].Rows.Count; i += 1)
                    {
                        lbox產品.Items.Add(string.Format("{0}", ds1.Tables["name"].Rows[i][1]));
                    }
                }
                else
                {
                    MessageBox.Show("請輸入欲搜尋的產品名稱");
                }
            }
        }

        private void btn新增_Click(object sender, EventArgs e)
        {
            DialogResult R;
            using (SqlConnection con = new SqlConnection(Global.scsb))
            {
                con.Open();

                if ((tb品名.Text.Length > 0) && (tb價格.Text.Length > 0))
                {
                    R = MessageBox.Show("您確認要新增產品資料?", "確認新增", MessageBoxButtons.YesNo, MessageBoxIcon.Information);

                    if (R == DialogResult.Yes)
                    {
                        string strSQL = "insert into products (p_name, p_spec, p_price, p_status) values(@NewName,@NewSpec,@NewPrice,@NewStatus)";
                        SqlCommand cmd = new SqlCommand(strSQL, con);

                        cmd.Parameters.AddWithValue("@NewName", tb品名.Text);
                        cmd.Parameters.AddWithValue("@NewSpec", tb規格.Text);

                        int intPrice = 0;
                        Int32.TryParse(tb價格.Text,out intPrice);
                        cmd.Parameters.AddWithValue("@NewPrice", intPrice);

                        cmd.Parameters.AddWithValue("@NewStatus", (bool)chk狀態.Checked);
                        
                        int rows = cmd.ExecuteNonQuery();

                        //MessageBox.Show(string.Format("資料新增完成,共新增{0}筆產品資料", rows));
                    }
                    else
                    {
                        //MessageBox.Show("已取消新增");
                    }
                }
                else
                {
                    MessageBox.Show("您提供的產品資訊不完整");
                }
            }
            syncListBox();
        }

        private void btn刪除_Click(object sender, EventArgs e)
        {
            int intID = 0;//修改資料: 以ID為依據
            Int32.TryParse(tb產品編號.Text, out intID);//將tb產品編號 轉為int型態
            DialogResult R;

            using (SqlConnection con = new SqlConnection(Global.scsb))
            {
                con.Open();
                if ((tb品名.Text.Length > 1) && (tb價格.Text.Length > 0))
                {
                    R = MessageBox.Show("您確認要刪除資料?", "確認刪除", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);

                    if (R == DialogResult.Yes)
                    {
                        string strSQL = "delete from products where p_id= @SearchID";
                        SqlCommand cmd = new SqlCommand(strSQL, con);
                        cmd.Parameters.AddWithValue("@SearchID", intID);
                        int rows = cmd.ExecuteNonQuery();
                        //MessageBox.Show(string.Format("已刪除{0}筆客戶資料", rows));

                        //將欄位清空
                        tb品名.Text = "";
                        tb規格.Text = "";
                        tb價格.Text = "";
                        chk狀態.Checked=false;
                    }
                    else
                    {
                        //MessageBox.Show("已取消刪除");
                    }
                }
                else
                {
                    MessageBox.Show("您尚未選擇欲刪除的產品");
                }
            }
            syncListBox();
        }

        private void btn修改_Click(object sender, EventArgs e)
        {
            int intID = 0;//修改資料: 以ID為依據
            Int32.TryParse(tb產品編號.Text, out intID);//將tb產品編號 轉為int型態
            DialogResult R;

            using (SqlConnection con = new SqlConnection(Global.scsb))
            {
                con.Open();
                if ((tb品名.Text.Length > 1) && (tb價格.Text.Length > 0))
                {
                    R = MessageBox.Show("您確認要修改資料?", "確認修改", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);

                    if (R == DialogResult.Yes)
                    {
                        string strSQL = "update products set p_name=@NewName, p_spec=@NewSpec, p_price=@NewPrice, p_status=@NewStatus where p_id=@SearchID";
                        SqlCommand cmd = new SqlCommand(strSQL, con);
                        cmd.Parameters.AddWithValue("@SearchID", intID);
                        cmd.Parameters.AddWithValue("@NewName", tb品名.Text);
                        cmd.Parameters.AddWithValue("@NewSpec", tb規格.Text);

                        int intPrice = 0;
                        Int32.TryParse(tb價格.Text, out intPrice);
                        cmd.Parameters.AddWithValue("@NewPrice", intPrice);

                        cmd.Parameters.AddWithValue("@NewStatus", (bool)chk狀態.Checked);

                        int rows = cmd.ExecuteNonQuery();

                        //MessageBox.Show(string.Format("資料新增完成,共修改了{0}筆產品資料", rows));
                    }
                    else
                    {
                        //MessageBox.Show("已取消修改");
                    }
                }
                else
                {
                    MessageBox.Show("您尚未選擇欲修改的產品");
                }
            }
            syncListBox();
        }

        private void btn所有產品_Click(object sender, EventArgs e)
        {
            syncListBox();
        }

        public void syncListBox()
        {
            using (SqlConnection con = new SqlConnection(Global.scsb))
            {
                con.Open();

                lbox產品.Items.Clear();//先清除 再重新讀取
                string strSQL = "select*from products";
                DataSet ds = new DataSet();
                SqlDataAdapter sqlDataAdapter = new SqlDataAdapter(strSQL, con);
                sqlDataAdapter.Fill(ds, "newNameList");

                for (int i = 0; i < ds.Tables["newNameList"].Rows.Count; i += 1)
                {
                    lbox產品.Items.Add(string.Format("{0}", ds.Tables["newNameList"].Rows[i][1]));
                }
            }

        }

        private void btn新增訂單_Click(object sender, EventArgs e)
        {
            
        }

        private void btn顧客維護_Click(object sender, EventArgs e)
        {
            
        }

        private void btn營運分析_Click(object sender, EventArgs e)
        {
            
        }

        private void btn訂單管理_Click(object sender, EventArgs e)
        {
            
        }

        private void btn回主頁_Click(object sender, EventArgs e)
        {
            functionList2 functionList2 = new functionList2();
            this.Hide();
            functionList2.ShowDialog();
        }

        private void btn關閉_Click(object sender, EventArgs e)
        {
            System.Environment.Exit(System.Environment.ExitCode);//強制關閉程式
        }

        private void btn選擇圖片_Click(object sender, EventArgs e)
        {
            try
            {
                if (openFileDialog.ShowDialog() == DialogResult.OK)
                {
                    FileInfo file = new FileInfo(openFileDialog.FileName);
                    pictureBox上傳.Image = Image.FromFile(openFileDialog.FileName);
                }
                pictureBox上傳.Visible = true;
            }
            catch
            {
                MessageBox.Show("請重新整理");
            }
            
        }

        private void btn上傳_Click(object sender, EventArgs e)
        {           

            try
            {
                using (SqlConnection con = new SqlConnection(Global.scsb))
                {
                    con.Open();
                    string strSQL = "update products set p_image = bulkcolumn FROM OPENROWSET(BULK '" + openFileDialog.FileName + "', SINGLE_BLOB) as p_image where p_id='" + tb產品編號.Text + "'";
                    SqlCommand cmd = new SqlCommand(strSQL, con);
                    if (openFileDialog.FileName.Equals("openFileDialog"))
                    {
                        MessageBox.Show("圖片不存在, 請確認選取圖片");
                    }
                    else
                    {
                        cmd.ExecuteNonQuery();
                        MessageBox.Show("已上傳圖片");
                        openFileDialog = null;
                    }
                }
            }
            catch(Exception ex)
            {
                MessageBox.Show("請選擇圖片");
            }
            
        }
    }
}
