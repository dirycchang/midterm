﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OrderWonton
{
    class Global
    {
        public static string scsb = @"Data Source=.;Initial Catalog=WontonDB;Integrated Security=True";
    }
}
