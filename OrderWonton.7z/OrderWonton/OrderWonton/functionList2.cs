﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace OrderWonton
{
    public partial class functionList2 : Form
    {
        public functionList2()
        {
            InitializeComponent();
        }

        private void functionList2_Load(object sender, EventArgs e)
        {

        }

        private void btn新增訂單_Click(object sender, EventArgs e)
        {
            ordersPlacing ordersPlacing = new ordersPlacing();
            this.Hide();
            ordersPlacing.ShowDialog();
        }

        private void btn訂單管理_Click(object sender, EventArgs e)
        {
            ordersFollowUp ordersFollowUp = new ordersFollowUp();
            this.Hide();
            ordersFollowUp.ShowDialog();
        }

        private void btn客戶維護_Click(object sender, EventArgs e)
        {
            customerMgnt myCustomerMgnt = new customerMgnt();
            this.Hide();
            myCustomerMgnt.ShowDialog();
        }

        private void btn產品維護_Click(object sender, EventArgs e)
        {
            productMgnt myProductMgnt = new productMgnt();
            this.Hide();
            myProductMgnt.ShowDialog();
        }

        private void btn營運分析_Click(object sender, EventArgs e)
        {
            OperationalAnalysis myOperationalAnalysis = new OperationalAnalysis();
            this.Hide();
            myOperationalAnalysis.ShowDialog();
        }
    }
}
