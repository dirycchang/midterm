﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.IO;
using System.Windows.Forms;

namespace OrderWonton
{
    public partial class customerMgnt : Form
    {
        SqlConnectionStringBuilder scsb;

        public customerMgnt()
        {
            InitializeComponent();
        }

        

        private void customerMgnt_Load(object sender, EventArgs e)
        {
            tb查詢.Select();

            using (SqlConnection con =new SqlConnection(Global.scsb))
            {
                con.Open();

                string strSQL = "select c_name from customers";
                SqlDataAdapter sqlDataAdapter = new SqlDataAdapter(strSQL,con);
                DataSet ds1 = new DataSet();
                sqlDataAdapter.Fill(ds1,"customerName");

                for (int i = 0; i < ds1.Tables["customerName"].Rows.Count; i+=1)
                {
                    lbox客戶.Items.Add(ds1.Tables["customerName"].Rows[i][0]);
                }
            }
        }

        

        private void lbox客戶_SelectedIndexChanged(object sender, EventArgs e)
        {
            string strSearchName = lbox客戶.SelectedItem.ToString();

            using (SqlConnection con =new SqlConnection(Global.scsb))
            {
                con.Open();
                if (strSearchName.Length > 0)
                {
                    string strSQL = "select*from customers where c_name like @SearchName";
                    SqlCommand cmd = new SqlCommand(strSQL,con);
                    cmd.Parameters.AddWithValue("@SearchName","%"+strSearchName+"%");
                    SqlDataReader reader = cmd.ExecuteReader();

                    if (reader.Read()==true)
                    {
                        tb顧客編號.Text = string.Format("{0}", reader["c_id"]);
                        tb姓名.Text = string.Format("{0}",reader["c_name"]);
                        tb小名.Text = string.Format("{0}", reader["c_nickname"]);
                        tb電話.Text = string.Format("{0}", reader["c_phone"]);
                        tb地址.Text = string.Format("{0}", reader["c_address"]);
                        tb備註.Text = string.Format("{0}", reader["c_remark"]);
                    }
                    else
                    {
                        MessageBox.Show("查無此人");
                        tb顧客編號.Text = "";
                        tb姓名.Text = "";
                        tb小名.Text = "";
                        tb電話.Text = "";
                        tb地址.Text = "";
                        tb備註.Text = "";
                    }
                }
                else
                {
                    MessageBox.Show("查無此客戶");
                }

                //顯示圖片
                using (SqlConnection con2 = new SqlConnection(Global.scsb))
                {
                    string strSQL2 = "select c_image from customers where c_name = '" + lbox客戶.Text + "'";
                    SqlDataAdapter sqlDataAdapter2 = new SqlDataAdapter(strSQL2, con2);
                    DataSet ds2 = new DataSet();
                    sqlDataAdapter2.Fill(ds2, "customerimage");
                    try
                    {
                        byte[] Bytes = (byte[])ds2.Tables["customerimage"].Rows[0][0];
                        pictureBox上傳.Image = Image.FromStream(new MemoryStream(Bytes));
                    }
                    catch
                    {
                        pictureBox上傳.Image = null;
                    }
                }
            }

            
        }

        private void btn查詢_Click(object sender, EventArgs e)
        {
            lbox客戶.Items.Clear();

            using (SqlConnection con = new SqlConnection(Global.scsb))
            {
                con.Open();

                if (tb查詢.Text.Length > 0)
                {
                    string strSQL = "select*from customers where c_name like '%"+tb查詢.Text+"%'";
                    DataSet ds1 = new DataSet();
                    SqlDataAdapter sqlDataAdapter = new SqlDataAdapter(strSQL, con);                    
                    sqlDataAdapter.Fill(ds1, "name");                                       

                    for (int i = 0; i < ds1.Tables["name"].Rows.Count; i+=1)
                    {
                        lbox客戶.Items.Add(string.Format("{0}",ds1.Tables["name"].Rows[i][1]));
                    }
                }
                else
                {
                    MessageBox.Show("請輸入欲搜尋的客戶名字");
                }
            }
                
        }

        private void btn新增_Click(object sender, EventArgs e)
        {
            DialogResult R;

            using (SqlConnection con = new SqlConnection(Global.scsb))
            {
                con.Open();

                if ((tb姓名.Text.Length>1)&&(tb電話.Text.Length>8))
                {
                    R = MessageBox.Show("您確認要新增客戶資料?","確認新增",MessageBoxButtons.YesNo,MessageBoxIcon.Information);

                    if (R==DialogResult.Yes)
                    {
                        string strSQL = "insert into customers(c_name,c_nickname,c_phone,c_address,c_remark) values(@NewName,@NewNickName,@NewPhone,@NewAddress,@NewRemark)";
                        SqlCommand cmd = new SqlCommand(strSQL, con);

                        cmd.Parameters.AddWithValue("@NewName", tb姓名.Text);
                        cmd.Parameters.AddWithValue("@NewNickName", tb小名.Text);
                        cmd.Parameters.AddWithValue("@NewPhone", tb電話.Text);
                        cmd.Parameters.AddWithValue("@NewAddress", tb地址.Text);
                        cmd.Parameters.AddWithValue("@NewRemark", tb備註.Text);
                        //cmd.Parameters.AddWithValue("@NewImage",pictureBox上傳.Image);

                        int rows = cmd.ExecuteNonQuery();

                        
                    }
                    else
                    {
                        //MessageBox.Show("已取消新增");
                    }
                    
                }
                else
                {
                    MessageBox.Show("您提供的客戶資料不完整");
                }               

            }
            syncListBox();
        }

        private void btn刪除_Click(object sender, EventArgs e)
        {
            int intID = 0;//刪除資料: 以ID為依據(因不會重複)
            Int32.TryParse(tb顧客編號.Text, out intID);//轉為int型態
            DialogResult R;

            using (SqlConnection con = new SqlConnection(Global.scsb))
            {
                con.Open();

                if ((tb姓名.Text.Length > 1) && (tb電話.Text.Length > 8))
                {
                    R = MessageBox.Show("您確認要刪除資料?", "確認刪除", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);

                    if (R==DialogResult.Yes)
                    {
                        string strSQL = "delete from customers where c_id= @SearchID";
                        SqlCommand cmd = new SqlCommand(strSQL, con);
                        cmd.Parameters.AddWithValue("@SearchID", intID);
                        int rows = cmd.ExecuteNonQuery();
                        //MessageBox.Show(string.Format("已刪除{0}筆客戶資料",rows));

                        //將欄位清空
                        tb姓名.Text = "";
                        tb小名.Text = "";
                        tb電話.Text = "";
                        tb地址.Text = "";
                        tb備註.Text = "";
                    }
                    else
                    {
                        //MessageBox.Show("已取消刪除");
                    }                                       
                }
                else
                {
                    MessageBox.Show("您尚未選擇欲刪除的客戶");
                }                
            }
            syncListBox();
        }        


        private void btn修改_Click(object sender, EventArgs e)
        {
            int intID = 0;//修改資料: 以ID為依據(因不會重複)
            Int32.TryParse(tb顧客編號.Text, out intID);//轉為int型態
            DialogResult R;

            using (SqlConnection con = new SqlConnection(Global.scsb))
            {
                con.Open();
                if ((tb姓名.Text.Length > 1) && (tb電話.Text.Length > 8))
                {
                    R = MessageBox.Show("您確認要修改資料?", "確認修改", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);

                    if (R == DialogResult.Yes)
                    {
                        string strSQL = "update customers set c_name=@NewName, c_nickname=@NewNickName, c_phone=@NewPhone, c_address=@NewAddress, c_remark=@NewRemark where c_id=@SearchID";
                        SqlCommand cmd = new SqlCommand(strSQL,con);

                        cmd.Parameters.AddWithValue("@SearchID",intID);
                        cmd.Parameters.AddWithValue("@NewName", tb姓名.Text);
                        cmd.Parameters.AddWithValue("@NewNickName", tb小名.Text);
                        cmd.Parameters.AddWithValue("@NewPhone", tb電話.Text);
                        cmd.Parameters.AddWithValue("@NewAddress", tb地址.Text);
                        cmd.Parameters.AddWithValue("@NewRemark", tb備註.Text);

                        int rows = cmd.ExecuteNonQuery();

                        //MessageBox.Show(string.Format("您修改了{0}筆客戶資料", rows));
                    }
                    else
                    {
                        //MessageBox.Show("已取消修改");
                    }
                }
                else
                {
                    MessageBox.Show("您尚未選擇欲修改的項目");
                }

            }
            syncListBox();
        }

        

        private void btn所有客戶_Click(object sender, EventArgs e)
        {
            syncListBox();
        }

        //將異動後最新的資料 同步更新到ListBox中的方法
        public void syncListBox()
        {
            using (SqlConnection con = new SqlConnection(Global.scsb))
            {
                con.Open();

                lbox客戶.Items.Clear();//先清除 再重新讀取
                string strSQL = "select*from customers";
                DataSet ds = new DataSet();
                SqlDataAdapter sqlDataAdapter = new SqlDataAdapter(strSQL, con);
                sqlDataAdapter.Fill(ds, "newNameList");

                for (int i = 0; i < ds.Tables["newNameList"].Rows.Count; i += 1)
                {
                    lbox客戶.Items.Add(string.Format("{0}", ds.Tables["newNameList"].Rows[i][1]));
                }
            }

        }

    

        private void btn新增訂單_Click(object sender, EventArgs e)
        {
            
        }

        private void btn產品維護_Click(object sender, EventArgs e)
        {
            
        }

        private void btn營運分析_Click(object sender, EventArgs e)
        {
            
        }

        private void btn回主頁_Click(object sender, EventArgs e)
        {
            functionList2 fl2 = new functionList2();
            this.Hide();
            fl2.ShowDialog();
        }

        private void btn關閉_Click(object sender, EventArgs e)
        {
            System.Environment.Exit(System.Environment.ExitCode);//強制關閉程式
        }

        private void btn選擇圖片_Click(object sender, EventArgs e)
        {
            try
            {
                if (openFileDialog.ShowDialog() == DialogResult.OK)
                {
                    FileInfo file = new FileInfo(openFileDialog.FileName);
                    pictureBox上傳.Image = Image.FromFile(openFileDialog.FileName);
                }
                pictureBox上傳.Visible = true;
            }
            catch
            {
                MessageBox.Show("請重新整理");
            }
            
        }

        private void btn上傳_Click(object sender, EventArgs e)
        {
            try
            {
                using (SqlConnection con = new SqlConnection(Global.scsb))
                {
                    con.Open();
                    string strSQL = "update customers set c_image = bulkcolumn FROM OPENROWSET(BULK '" + openFileDialog.FileName + "', SINGLE_BLOB) as c_image where c_id='" + tb顧客編號.Text + "'";
                    SqlCommand cmd = new SqlCommand(strSQL, con);

                    if (openFileDialog.FileName.Equals("openFileDialog"))
                    {
                        MessageBox.Show("圖片不存在, 請確認選取圖片");
                    }
                    else
                    {
                        cmd.ExecuteNonQuery();
                        MessageBox.Show("已上傳圖片");
                    }

                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("請選擇圖片");
            }
        }
    }
}
