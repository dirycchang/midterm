﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace OrderWonton
{
    public partial class ordersFollowUp : Form
    {
        SqlConnectionStringBuilder scsb;

        public ordersFollowUp()
        {
            InitializeComponent();
        }

        private void ordersFollowUp_Load(object sender, EventArgs e)
        {
            theLastestFollowUpData();
            timer1.Enabled = true;
        }

        private void theLastestFollowUpData()
        {
            using (SqlConnection con = new SqlConnection(Global.scsb))
            {
                //更新待處理訂單(只要未付款 或 未取貨 的訂單都放這)
                string strSQL = "select o.o_id,o.o_pickupdate as 預計出貨日,o.o_date as 下單日期, c.c_name as 訂購人, c.c_nickname as 綽號,p.p_name as 產品名稱, p.p_price as 單價,o.o_qty as 數量, o.o_totalprice as 總計, o.o_pickup as 取貨方式,o.o_paystatus as 付款狀態 from orders o inner join customers c on o.c_id = c.c_id inner join products p on o.p_id = p.p_id where o.o_pickup !='已取貨' or o.o_paystatus!='已付款'  order by 2 desc,1 asc, 3 desc,4";
                DataSet ds = new DataSet();
                SqlDataAdapter sda = new SqlDataAdapter(strSQL, con);
                sda.Fill(ds, "followUp");
                dataGridView1.DataSource = ds.Tables["followUp"];
                dataGridView1.Columns[0].Visible = false;

                //更新已完成訂單 (只存放 已付款 且 已取貨 的訂單)
                string strSQL2 = "select o.o_id,o.o_pickupdate as 預計出貨日,o.o_date as 下單日期, c.c_name as 訂購人, c.c_nickname as 綽號,p.p_name as 產品名稱, p.p_price as 單價,o.o_qty as 數量, o.o_totalprice as 總計, o.o_pickup as 取貨方式,o.o_paystatus as 付款狀態 from orders o inner join customers c on o.c_id = c.c_id inner join products p on o.p_id = p.p_id where o.o_pickup ='已取貨' and o.o_paystatus='已付款' order by 2 desc,1 asc, 3 desc,4";
                DataSet ds2 = new DataSet();
                SqlDataAdapter sda2 = new SqlDataAdapter(strSQL2, con);
                sda2.Fill(ds2, "followUp2");
                dataGridView2.DataSource = ds2.Tables["followUp2"];
                dataGridView2.Columns[0].Visible = false;
            }
        }

        private void btn確認付款_Click(object sender, EventArgs e)
        {
            DialogResult R = MessageBox.Show("該訂購人是否已付款?","確認付款資訊",MessageBoxButtons.YesNo,MessageBoxIcon.Question);
            if (R==DialogResult.Yes)
            {
                using (SqlConnection con = new SqlConnection(Global.scsb))
                {
                    string strUpdate = $"{dataGridView1.SelectedRows[0].Index.ToString()}";
                    int Update;
                    Int32.TryParse(strUpdate,out Update);
                    DataSet ds = new DataSet();
                    SqlDataAdapter sda = new SqlDataAdapter("update orders set o_paystatus='已付款' where o_id='"+dataGridView1.Rows[Update].Cells[0].Value+"'", con);
                    sda.Fill(ds,"updateData");
                    dataGridView1.DataSource = ds.Tables["updateData"];

                    theLastestFollowUpData();
                }
                //MessageBox.Show("更新為\"已付款\"");
            }           
            
        }

        private void btn確認取貨_Click(object sender, EventArgs e)
        {
            DialogResult R = MessageBox.Show("該訂購人是否已取貨?", "確認取貨資訊", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (R == DialogResult.Yes)
            {
                using (SqlConnection con = new SqlConnection(Global.scsb))
                {
                    string strUpdate = $"{dataGridView1.SelectedRows[0].Index.ToString()}";
                    int Update;
                    Int32.TryParse(strUpdate, out Update);
                    DataSet ds = new DataSet();
                    SqlDataAdapter sda = new SqlDataAdapter("update orders set o_pickup='已取貨' where o_id='" + dataGridView1.Rows[Update].Cells[0].Value + "'", con);
                    sda.Fill(ds, "updatePickup");
                    dataGridView1.DataSource = ds.Tables["updatePickup"];

                    theLastestFollowUpData();
                }
                //MessageBox.Show("更新為\"已取貨\"");
            }
        }


        private void btn取消訂單_Click(object sender, EventArgs e)
        {
            DialogResult myResult = MessageBox.Show("您確定要刪除該筆訂單", "取消訂單", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

            if (myResult == DialogResult.Yes)
            {
                using (SqlConnection con = new SqlConnection(Global.scsb))
                {
                    if (dataGridView1.Rows[0].Index >= 0 )
                    {
                        string strDelete = $"{dataGridView1.SelectedRows[0].Index.ToString()}";
                        int Delete;
                        Int32.TryParse(strDelete, out Delete);
                        DataSet ds = new DataSet();
                        SqlDataAdapter SQL = new SqlDataAdapter("delete from orders where o_id = " + dataGridView1.Rows[Delete].Cells[0].Value + "", con);
                        SQL.Fill(ds, "取消");
                        dataGridView1.DataSource = ds.Tables["取消"];

                        theLastestFollowUpData();

                        
                    }
                    else
                    {
                        MessageBox.Show("已放棄取消該筆訂單");
                    }

                }
            }

        }


        private void btn新增訂購_Click(object sender, EventArgs e)
        {
            
        }

        private void btn產品維護_Click(object sender, EventArgs e)
        {
            
        }

        private void btn營運分析_Click(object sender, EventArgs e)
        {
            
        }

        private void btn顧客維護_Click(object sender, EventArgs e)
        {
            
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            lbl目前時間.Text = string.Format("{0:F}", DateTime.Now);
        }

        private void btn退費_Click(object sender, EventArgs e)
        {
            DialogResult R = MessageBox.Show("該訂購人是否要求退款?", "確認退款資訊", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (R == DialogResult.Yes)
            {
                using (SqlConnection con = new SqlConnection(Global.scsb))
                {
                    string strUpdate = $"{dataGridView2.SelectedRows[0].Index.ToString()}";
                    int Update;
                    Int32.TryParse(strUpdate, out Update);
                    DataSet ds = new DataSet();
                    SqlDataAdapter sda = new SqlDataAdapter("update orders set o_paystatus='已退費' where o_id='" + dataGridView2.Rows[Update].Cells[0].Value + "'", con);
                    sda.Fill(ds, "updateData");
                    dataGridView2.DataSource = ds.Tables["updateData"];

                    theLastestFollowUpData();
                }
                MessageBox.Show("已將該筆訂單標註為\"已退款\" 並移至\"待處理訂單\"中");
            }
        }
        //篩選特定日期的訂單
        private void dateTimePicker1_ValueChanged(object sender, EventArgs e)
        {
            string strDate = string.Format("{0:yyyy-MM-dd}", dateTimePicker1.Value);//將dateTimePicker1選到的日期 轉型為字串 (為了放進SQL指令中)

            using (SqlConnection con = new SqlConnection(Global.scsb))
            {
                //將結果 顯示在 "待處理訂單" 之頁簽中
                string strSQL = "select o.o_id,o.o_pickupdate as 預計出貨日,o.o_date as 下單日期, c.c_name as 訂購人, c.c_nickname as 綽號,p.p_name as 產品名稱, p.p_price as 單價,o.o_qty as 數量, o.o_totalprice as 總計, o.o_pickup as 取貨方式,o.o_paystatus as 付款狀態 from orders o inner join customers c on o.c_id = c.c_id inner join products p on o.p_id = p.p_id where o.o_date='"+ strDate + "' and o.o_pickup !='已取貨' or o.o_paystatus!='已付款' order by 2 desc,1 asc, 3 desc,4";
                DataSet ds1 = new DataSet();                
                SqlDataAdapter sda1 = new SqlDataAdapter(strSQL, con);
                sda1.Fill(ds1, "selectWhichOne");
                dataGridView1.DataSource = ds1.Tables["selectWhichOne"];

                //將結果 顯示在 "已完成" 之頁簽中
                string strSQL2 = "select o.o_id,o.o_pickupdate as 預計出貨日,o.o_date as 下單日期, c.c_name as 訂購人, c.c_nickname as 綽號,p.p_name as 產品名稱, p.p_price as 單價,o.o_qty as 數量, o.o_totalprice as 總計, o.o_pickup as 取貨方式,o.o_paystatus as 付款狀態 from orders o inner join customers c on o.c_id = c.c_id inner join products p on o.p_id = p.p_id where o.o_date='" + strDate + "' and o.o_pickup ='已取貨' and o.o_paystatus='已付款' order by 2 desc,1 asc, 3 desc,4";
                DataSet ds2 = new DataSet();
                SqlDataAdapter sda2 = new SqlDataAdapter(strSQL2, con);
                sda2.Fill(ds2, "selectWhichTwo");
                dataGridView2.DataSource = ds2.Tables["selectWhichTwo"];
                                
                dataGridView1.Columns[0].Visible = false;
                dataGridView2.Columns[0].Visible = false;
            }
                
        }

        private void btn重新整理_Click(object sender, EventArgs e)
        {
            ordersFollowUp of = new ordersFollowUp();
            this.Hide();
            of.ShowDialog();
        }

        private void btn回主頁_Click(object sender, EventArgs e)
        {
            functionList2 functionList2 = new functionList2();
            this.Hide();
            functionList2.ShowDialog();
        }

        private void btn關閉_Click(object sender, EventArgs e)
        {
            System.Environment.Exit(System.Environment.ExitCode);//強制關閉程式
        }
    }
}
