﻿namespace OrderWonton
{
    partial class ordersFollowUp
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.btn確認付款 = new System.Windows.Forms.Button();
            this.btn確認取貨 = new System.Windows.Forms.Button();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.label1 = new System.Windows.Forms.Label();
            this.btn回主頁 = new System.Windows.Forms.Button();
            this.btn取消訂單 = new System.Windows.Forms.Button();
            this.lbl目前時間 = new System.Windows.Forms.Label();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.btn重新整理 = new System.Windows.Forms.Button();
            this.btn退費 = new System.Windows.Forms.Button();
            this.dataGridView2 = new System.Windows.Forms.DataGridView();
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.label2 = new System.Windows.Forms.Label();
            this.btn關閉 = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.tabPage2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).BeginInit();
            this.SuspendLayout();
            // 
            // btn確認付款
            // 
            this.btn確認付款.BackColor = System.Drawing.Color.Khaki;
            this.btn確認付款.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn確認付款.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btn確認付款.Font = new System.Drawing.Font("微軟正黑體", 13.84615F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.btn確認付款.Location = new System.Drawing.Point(76, 426);
            this.btn確認付款.Margin = new System.Windows.Forms.Padding(4);
            this.btn確認付款.Name = "btn確認付款";
            this.btn確認付款.Size = new System.Drawing.Size(207, 49);
            this.btn確認付款.TabIndex = 6;
            this.btn確認付款.Text = "確認付款";
            this.btn確認付款.UseVisualStyleBackColor = false;
            this.btn確認付款.Click += new System.EventHandler(this.btn確認付款_Click);
            // 
            // btn確認取貨
            // 
            this.btn確認取貨.BackColor = System.Drawing.Color.Khaki;
            this.btn確認取貨.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn確認取貨.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btn確認取貨.Font = new System.Drawing.Font("微軟正黑體", 13.84615F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.btn確認取貨.Location = new System.Drawing.Point(395, 426);
            this.btn確認取貨.Margin = new System.Windows.Forms.Padding(4);
            this.btn確認取貨.Name = "btn確認取貨";
            this.btn確認取貨.Size = new System.Drawing.Size(207, 49);
            this.btn確認取貨.TabIndex = 7;
            this.btn確認取貨.Text = "確認取貨";
            this.btn確認取貨.UseVisualStyleBackColor = false;
            this.btn確認取貨.Click += new System.EventHandler(this.btn確認取貨_Click);
            // 
            // dataGridView1
            // 
            this.dataGridView1.AllowUserToDeleteRows = false;
            this.dataGridView1.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            this.dataGridView1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Cursor = System.Windows.Forms.Cursors.AppStarting;
            this.dataGridView1.GridColor = System.Drawing.SystemColors.Highlight;
            this.dataGridView1.Location = new System.Drawing.Point(14, 41);
            this.dataGridView1.Margin = new System.Windows.Forms.Padding(4);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.ReadOnly = true;
            this.dataGridView1.RowHeadersVisible = false;
            this.dataGridView1.RowTemplate.Height = 29;
            this.dataGridView1.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridView1.Size = new System.Drawing.Size(980, 356);
            this.dataGridView1.TabIndex = 9;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("微軟正黑體", 18.27692F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label1.Location = new System.Drawing.Point(54, 27);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(381, 42);
            this.label1.TabIndex = 10;
            this.label1.Text = "請確認以下每筆訂單資訊";
            // 
            // btn回主頁
            // 
            this.btn回主頁.BackColor = System.Drawing.Color.Goldenrod;
            this.btn回主頁.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn回主頁.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btn回主頁.Font = new System.Drawing.Font("微軟正黑體", 13.84615F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.btn回主頁.Location = new System.Drawing.Point(426, 657);
            this.btn回主頁.Margin = new System.Windows.Forms.Padding(4);
            this.btn回主頁.Name = "btn回主頁";
            this.btn回主頁.Size = new System.Drawing.Size(238, 70);
            this.btn回主頁.TabIndex = 13;
            this.btn回主頁.Text = "回主頁";
            this.btn回主頁.UseVisualStyleBackColor = false;
            this.btn回主頁.Click += new System.EventHandler(this.btn回主頁_Click);
            // 
            // btn取消訂單
            // 
            this.btn取消訂單.BackColor = System.Drawing.Color.Khaki;
            this.btn取消訂單.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn取消訂單.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btn取消訂單.Font = new System.Drawing.Font("微軟正黑體", 13.84615F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.btn取消訂單.ForeColor = System.Drawing.Color.Firebrick;
            this.btn取消訂單.Location = new System.Drawing.Point(720, 426);
            this.btn取消訂單.Margin = new System.Windows.Forms.Padding(4);
            this.btn取消訂單.Name = "btn取消訂單";
            this.btn取消訂單.Size = new System.Drawing.Size(207, 49);
            this.btn取消訂單.TabIndex = 14;
            this.btn取消訂單.Text = "刪除訂單";
            this.btn取消訂單.UseVisualStyleBackColor = false;
            this.btn取消訂單.Click += new System.EventHandler(this.btn取消訂單_Click);
            // 
            // lbl目前時間
            // 
            this.lbl目前時間.AutoSize = true;
            this.lbl目前時間.Font = new System.Drawing.Font("微軟正黑體", 16.06154F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.lbl目前時間.Location = new System.Drawing.Point(750, 16);
            this.lbl目前時間.Name = "lbl目前時間";
            this.lbl目前時間.Size = new System.Drawing.Size(137, 38);
            this.lbl目前時間.TabIndex = 15;
            this.lbl目前時間.Text = "目前時間";
            // 
            // timer1
            // 
            this.timer1.Interval = 50;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Font = new System.Drawing.Font("微軟正黑體", 13.84615F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.tabControl1.Location = new System.Drawing.Point(43, 82);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(1026, 540);
            this.tabControl1.TabIndex = 16;
            // 
            // tabPage1
            // 
            this.tabPage1.BackColor = System.Drawing.Color.LemonChiffon;
            this.tabPage1.Controls.Add(this.dataGridView1);
            this.tabPage1.Controls.Add(this.btn確認付款);
            this.tabPage1.Controls.Add(this.btn取消訂單);
            this.tabPage1.Controls.Add(this.btn確認取貨);
            this.tabPage1.Location = new System.Drawing.Point(4, 41);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(1018, 495);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "待處理訂單";
            // 
            // tabPage2
            // 
            this.tabPage2.BackColor = System.Drawing.Color.LemonChiffon;
            this.tabPage2.Controls.Add(this.btn重新整理);
            this.tabPage2.Controls.Add(this.btn退費);
            this.tabPage2.Controls.Add(this.dataGridView2);
            this.tabPage2.Location = new System.Drawing.Point(4, 41);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(1018, 495);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "已完成";
            // 
            // btn重新整理
            // 
            this.btn重新整理.BackColor = System.Drawing.Color.Khaki;
            this.btn重新整理.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn重新整理.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btn重新整理.Font = new System.Drawing.Font("微軟正黑體", 13.84615F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.btn重新整理.Image = global::OrderWonton.Properties.Resources.if_refresh_16088091;
            this.btn重新整理.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn重新整理.Location = new System.Drawing.Point(545, 431);
            this.btn重新整理.Margin = new System.Windows.Forms.Padding(4);
            this.btn重新整理.Name = "btn重新整理";
            this.btn重新整理.Size = new System.Drawing.Size(196, 49);
            this.btn重新整理.TabIndex = 12;
            this.btn重新整理.Text = "重新整理";
            this.btn重新整理.UseVisualStyleBackColor = false;
            this.btn重新整理.Click += new System.EventHandler(this.btn重新整理_Click);
            // 
            // btn退費
            // 
            this.btn退費.BackColor = System.Drawing.Color.Khaki;
            this.btn退費.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn退費.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btn退費.Font = new System.Drawing.Font("微軟正黑體", 13.84615F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.btn退費.Location = new System.Drawing.Point(242, 431);
            this.btn退費.Margin = new System.Windows.Forms.Padding(4);
            this.btn退費.Name = "btn退費";
            this.btn退費.Size = new System.Drawing.Size(207, 49);
            this.btn退費.TabIndex = 11;
            this.btn退費.Text = "退款";
            this.btn退費.UseVisualStyleBackColor = false;
            this.btn退費.Click += new System.EventHandler(this.btn退費_Click);
            // 
            // dataGridView2
            // 
            this.dataGridView2.AllowUserToDeleteRows = false;
            this.dataGridView2.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            this.dataGridView2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.dataGridView2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView2.Cursor = System.Windows.Forms.Cursors.AppStarting;
            this.dataGridView2.GridColor = System.Drawing.SystemColors.Highlight;
            this.dataGridView2.Location = new System.Drawing.Point(14, 44);
            this.dataGridView2.Margin = new System.Windows.Forms.Padding(4);
            this.dataGridView2.Name = "dataGridView2";
            this.dataGridView2.ReadOnly = true;
            this.dataGridView2.RowHeadersVisible = false;
            this.dataGridView2.RowTemplate.Height = 29;
            this.dataGridView2.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridView2.Size = new System.Drawing.Size(985, 364);
            this.dataGridView2.TabIndex = 10;
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.Font = new System.Drawing.Font("微軟正黑體", 13.84615F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.dateTimePicker1.Location = new System.Drawing.Point(871, 57);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new System.Drawing.Size(198, 41);
            this.dateTimePicker1.TabIndex = 17;
            this.dateTimePicker1.ValueChanged += new System.EventHandler(this.dateTimePicker1_ValueChanged);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("微軟正黑體", 16.06154F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label2.Location = new System.Drawing.Point(662, 59);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(273, 38);
            this.label2.TabIndex = 18;
            this.label2.Text = "請選擇欲篩選日期: ";
            // 
            // btn關閉
            // 
            this.btn關閉.BackColor = System.Drawing.Color.LightCoral;
            this.btn關閉.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn關閉.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btn關閉.Font = new System.Drawing.Font("微軟正黑體", 13.84615F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.btn關閉.Image = global::OrderWonton.Properties.Resources.exit2;
            this.btn關閉.Location = new System.Drawing.Point(1087, -2);
            this.btn關閉.Margin = new System.Windows.Forms.Padding(4);
            this.btn關閉.Name = "btn關閉";
            this.btn關閉.Size = new System.Drawing.Size(34, 31);
            this.btn關閉.TabIndex = 19;
            this.btn關閉.UseVisualStyleBackColor = false;
            this.btn關閉.Click += new System.EventHandler(this.btn關閉_Click);
            // 
            // ordersFollowUp
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.Highlight;
            this.ClientSize = new System.Drawing.Size(1122, 740);
            this.Controls.Add(this.btn關閉);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.dateTimePicker1);
            this.Controls.Add(this.tabControl1);
            this.Controls.Add(this.lbl目前時間);
            this.Controls.Add(this.btn回主頁);
            this.Controls.Add(this.label1);
            this.Font = new System.Drawing.Font("微軟正黑體", 11.07692F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "ordersFollowUp";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "訂單追蹤";
            this.Load += new System.EventHandler(this.ordersFollowUp_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btn確認付款;
        private System.Windows.Forms.Button btn確認取貨;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btn回主頁;
        private System.Windows.Forms.Button btn取消訂單;
        private System.Windows.Forms.Label lbl目前時間;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.DataGridView dataGridView2;
        private System.Windows.Forms.Button btn退費;
        private System.Windows.Forms.DateTimePicker dateTimePicker1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button btn重新整理;
        private System.Windows.Forms.Button btn關閉;
    }
}