﻿namespace OrderWonton
{
    partial class functionList2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btn新增訂單 = new System.Windows.Forms.Button();
            this.btn營運分析 = new System.Windows.Forms.Button();
            this.btn產品維護 = new System.Windows.Forms.Button();
            this.btn客戶維護 = new System.Windows.Forms.Button();
            this.btn訂單管理 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btn新增訂單
            // 
            this.btn新增訂單.BackColor = System.Drawing.Color.Khaki;
            this.btn新增訂單.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn新增訂單.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btn新增訂單.Font = new System.Drawing.Font("微軟正黑體", 16.06154F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.btn新增訂單.Image = global::OrderWonton.Properties.Resources.order_2639879;
            this.btn新增訂單.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn新增訂單.Location = new System.Drawing.Point(85, 39);
            this.btn新增訂單.Name = "btn新增訂單";
            this.btn新增訂單.Size = new System.Drawing.Size(261, 79);
            this.btn新增訂單.TabIndex = 9;
            this.btn新增訂單.Text = "新增訂單";
            this.btn新增訂單.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btn新增訂單.UseVisualStyleBackColor = false;
            this.btn新增訂單.Click += new System.EventHandler(this.btn新增訂單_Click);
            // 
            // btn營運分析
            // 
            this.btn營運分析.BackColor = System.Drawing.Color.Khaki;
            this.btn營運分析.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn營運分析.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btn營運分析.Font = new System.Drawing.Font("微軟正黑體", 16.06154F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.btn營運分析.Image = global::OrderWonton.Properties.Resources.Analysis_2529943;
            this.btn營運分析.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn營運分析.Location = new System.Drawing.Point(85, 519);
            this.btn營運分析.Name = "btn營運分析";
            this.btn營運分析.Size = new System.Drawing.Size(261, 79);
            this.btn營運分析.TabIndex = 8;
            this.btn營運分析.Text = "營運分析";
            this.btn營運分析.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btn營運分析.UseVisualStyleBackColor = false;
            this.btn營運分析.Click += new System.EventHandler(this.btn營運分析_Click);
            // 
            // btn產品維護
            // 
            this.btn產品維護.BackColor = System.Drawing.Color.Khaki;
            this.btn產品維護.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn產品維護.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btn產品維護.Font = new System.Drawing.Font("微軟正黑體", 16.06154F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.btn產品維護.Image = global::OrderWonton.Properties.Resources.if_restaurant_12_3078511;
            this.btn產品維護.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn產品維護.Location = new System.Drawing.Point(85, 400);
            this.btn產品維護.Name = "btn產品維護";
            this.btn產品維護.Size = new System.Drawing.Size(261, 79);
            this.btn產品維護.TabIndex = 7;
            this.btn產品維護.Text = "產品維護";
            this.btn產品維護.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btn產品維護.UseVisualStyleBackColor = false;
            this.btn產品維護.Click += new System.EventHandler(this.btn產品維護_Click);
            // 
            // btn客戶維護
            // 
            this.btn客戶維護.BackColor = System.Drawing.Color.Khaki;
            this.btn客戶維護.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn客戶維護.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btn客戶維護.Font = new System.Drawing.Font("微軟正黑體", 16.06154F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.btn客戶維護.Image = global::OrderWonton.Properties.Resources.customers2;
            this.btn客戶維護.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn客戶維護.Location = new System.Drawing.Point(85, 274);
            this.btn客戶維護.Name = "btn客戶維護";
            this.btn客戶維護.Size = new System.Drawing.Size(261, 83);
            this.btn客戶維護.TabIndex = 6;
            this.btn客戶維護.Text = "客戶維護";
            this.btn客戶維護.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btn客戶維護.UseVisualStyleBackColor = false;
            this.btn客戶維護.Click += new System.EventHandler(this.btn客戶維護_Click);
            // 
            // btn訂單管理
            // 
            this.btn訂單管理.BackColor = System.Drawing.Color.Khaki;
            this.btn訂單管理.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn訂單管理.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btn訂單管理.Font = new System.Drawing.Font("微軟正黑體", 16.06154F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.btn訂單管理.Image = global::OrderWonton.Properties.Resources.choice3;
            this.btn訂單管理.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn訂單管理.Location = new System.Drawing.Point(85, 153);
            this.btn訂單管理.Name = "btn訂單管理";
            this.btn訂單管理.Size = new System.Drawing.Size(261, 79);
            this.btn訂單管理.TabIndex = 5;
            this.btn訂單管理.Text = "訂單管理";
            this.btn訂單管理.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btn訂單管理.UseVisualStyleBackColor = false;
            this.btn訂單管理.Click += new System.EventHandler(this.btn訂單管理_Click);
            // 
            // functionList2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.Highlight;
            this.ClientSize = new System.Drawing.Size(438, 641);
            this.Controls.Add(this.btn新增訂單);
            this.Controls.Add(this.btn營運分析);
            this.Controls.Add(this.btn產品維護);
            this.Controls.Add(this.btn客戶維護);
            this.Controls.Add(this.btn訂單管理);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "functionList2";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "functionList2";
            this.Load += new System.EventHandler(this.functionList2_Load);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btn新增訂單;
        private System.Windows.Forms.Button btn營運分析;
        private System.Windows.Forms.Button btn產品維護;
        private System.Windows.Forms.Button btn客戶維護;
        private System.Windows.Forms.Button btn訂單管理;
    }
}