﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace OrderWonton
{
    public partial class ordersPlacing : Form
    {
        SqlConnectionStringBuilder scsb;
        int intQty;
        int intPrice;
        string strPrice;

        public ordersPlacing()
        {
            InitializeComponent();
        }

        private void ordersPlacing_Load(object sender, EventArgs e)
        {
            lbl訂單日期.Text= string.Format("{0:yyyy-MM-dd}", DateTime.Now);
            using (SqlConnection con = new SqlConnection(Global.scsb))
            {
                con.Open();
                //選擇客戶
                string strSQL = "select c_name from customers";
                SqlDataAdapter sda = new SqlDataAdapter(strSQL,con);
                DataSet ds = new DataSet();
                sda.Fill(ds,"customerName");

                for (int i = 0; i < ds.Tables["customerName"].Rows.Count; i++)
                {
                    cbox客戶.Items.Add(ds.Tables["customerName"].Rows[i][0]);
                }

                //選擇產品
                string strSQL2 = "select p_name from products where p_status='True'";
                SqlDataAdapter sda2 = new SqlDataAdapter(strSQL2, con);
                DataSet ds2 = new DataSet();
                sda2.Fill(ds2, "productName");

                for (int i = 0; i < ds2.Tables["productName"].Rows.Count; i++)
                {
                    cbox選擇產品.Items.Add(ds2.Tables["productName"].Rows[i][0]);
                }
                               
            }
            
        }

        private void cbox選擇產品_SelectedIndexChanged(object sender, EventArgs e)
        {
            using (SqlConnection con = new SqlConnection(Global.scsb))
            {
                con.Open();

                //顯示單價
                string strSQL = "select p_price from products where p_name='"+cbox選擇產品.Text+"'";
                SqlDataAdapter sda = new SqlDataAdapter(strSQL,con);
                DataSet ds1 = new DataSet();
                sda.Fill(ds1,"unitPrice");

                for (int i = 0; i < ds1.Tables["unitPrice"].Rows.Count; i++)
                {
                    lbl單價.Text = string.Format("{0}",ds1.Tables["unitPrice"].Rows[i][0]);
                }
                Int32.TryParse(lbl單價.Text, out intPrice);


                //顯示規格
                string strSQL2 = "select p_spec from products where p_name='" + cbox選擇產品.Text + "'";
                SqlDataAdapter sda2 = new SqlDataAdapter(strSQL2, con);
                DataSet ds2 = new DataSet();
                sda2.Fill(ds2, "specification");

                for (int i = 0; i < ds2.Tables["specification"].Rows.Count; i++)
                {
                    lbl每包數量.Text = string.Format("{0}", ds2.Tables["specification"].Rows[i][0]);
                }

                //將價格找出來
                string strSQL3 = "select p_price from products where p_name='" + cbox選擇產品.Text + "'";
                SqlDataAdapter sda3 = new SqlDataAdapter(strSQL3, con);
                DataSet ds3 = new DataSet();
                sda3.Fill(ds3, "productPrice");

                if (ds3.Tables["productPrice"].Rows.Count == 0)
                {
                    MessageBox.Show("0");
                }
                else
                {
                    strPrice = string.Format("{0}", ds3.Tables["productPrice"].Rows[0][0]);
                    Int32.TryParse(strPrice, out intPrice);
                }

            }
            lbl小計.Text =$"{intPrice*intQty}";
        }

        private void btn減_Click(object sender, EventArgs e)
        {
            intQty -= 1;
            if (intQty < 0)
            {
                intQty = 0;
                btn減.Enabled = false;
            }
            tb數量.Text = intQty.ToString();
        }

        private void btn加_Click(object sender, EventArgs e)
        {
            intQty += 1;
            btn減.Enabled = true;
            tb數量.Text = intQty.ToString();
        }

        private void tb數量_TextChanged(object sender, EventArgs e)
        {//預防使用者輸入不合理的東西
            if (tb數量.Text!="")
            {
                bool ifNum = System.Int32.TryParse(tb數量.Text,out intQty);//用Try.Parse檢查只能輸入整數 才轉換成功

                if ((ifNum)&&(intQty >= 0))//輸入的轉換整數成功 且 大於等於0
                {
                    btn減.Enabled = true;
                }
                else
                {
                    MessageBox.Show("請輸入正確數字","輸入格式錯誤",MessageBoxButtons.OK,MessageBoxIcon.Error);
                    intQty = 0;
                    tb數量.Text = "0";
                }

            }
            else
            {
                intQty = 0;
            }
            lbl小計.Text = $"{intPrice*intQty}";
        }

        private void cbox客戶_SelectedIndexChanged(object sender, EventArgs e)
        {
            using (SqlConnection con = new SqlConnection(Global.scsb))
            {
                con.Open();

                //顯示聯絡方式
                string strSQL = "select c_phone from customers where c_name='" + cbox客戶.Text + "'";
                SqlDataAdapter sda = new SqlDataAdapter(strSQL, con);
                DataSet ds1 = new DataSet();
                sda.Fill(ds1, "CPhoneNum");

                for (int i = 0; i < ds1.Tables["CPhoneNum"].Rows.Count; i++)
                {
                    tb聯絡方式.Text = string.Format("{0}", ds1.Tables["CPhoneNum"].Rows[i][0]);
                }

                //顯示寄送地址
                string strSQL2 = "select c_address from customers where c_name='" + cbox客戶.Text + "'";
                SqlDataAdapter sda2 = new SqlDataAdapter(strSQL2, con);
                DataSet ds2 = new DataSet();
                sda2.Fill(ds2, "CAddress");

                for (int i = 0; i < ds2.Tables["CAddress"].Rows.Count; i++)
                {
                    tb寄送地址.Text = string.Format("{0}", ds2.Tables["CAddress"].Rows[i][0]);
                }
            }
        }

        private void btn取消_Click(object sender, EventArgs e)
        {
            
        }

        private void btn新增_Click(object sender, EventArgs e)
        {
            DialogResult R;

            using (SqlConnection con = new SqlConnection(Global.scsb))
            {
                con.Open();

                if (cbox客戶.Text.Length>0)
                {
                    if ((cbox選擇產品.Text.Length>0 )&&(cbox取貨方式.Text.Length>0)&&(tb數量.Text!="0"))
                    {
                        if (dtp預計取貨日.Value >= DateTime.Now)
                        {
                            R = MessageBox.Show("您確認要新增此訂單?", "確認新增", MessageBoxButtons.YesNo, MessageBoxIcon.Information);

                            if (R == DialogResult.Yes)
                            {
                                //取得客戶ID 並指定放到字串customerID中
                                DataSet ds1 = new DataSet();
                                SqlDataAdapter sda1 = new SqlDataAdapter("select c_id from customers where c_name='" + cbox客戶.Text + "'", con);
                                sda1.Fill(ds1, "cID");
                                string customerID = string.Format("{0}", ds1.Tables["cID"].Rows[0][0]);

                                //取得產品ID 並指定放到字串productID中
                                DataSet ds2 = new DataSet();
                                SqlDataAdapter sda2 = new SqlDataAdapter("select p_id from products where p_name='" + cbox選擇產品.Text + "'", con);
                                sda2.Fill(ds2, "pID");
                                string productID = string.Format("{0}", ds2.Tables["pID"].Rows[0][0]);

                                //取得日期
                                string strDate = string.Format("{0:yyyy-MM-dd}", DateTime.Now);
                                string strSQL = "insert into orders(c_id,p_id,o_date,o_qty,o_totalprice,o_pickup,o_paystatus,o_pickupdate) values(@c_id,@p_id,@o_date,@o_qty,@o_totalprice,@o_pickup,'未付款',@o_pickupdate)";
                                SqlCommand cmd = new SqlCommand(strSQL, con);
                                cmd.Parameters.AddWithValue("@c_id", customerID);
                                cmd.Parameters.AddWithValue("@p_id", productID);
                                cmd.Parameters.AddWithValue("@o_date", strDate);
                                cmd.Parameters.AddWithValue("@o_qty", tb數量.Text);
                                cmd.Parameters.AddWithValue("@o_totalprice", lbl小計.Text);
                                cmd.Parameters.AddWithValue("@o_pickup", cbox取貨方式.Text);
                                cmd.Parameters.AddWithValue("@o_pickupdate", (DateTime)dtp預計取貨日.Value);

                                int rows = cmd.ExecuteNonQuery();

                                //ordersPlacing ordersPlacing = new ordersPlacing();
                                //this.Hide();
                                //ordersPlacing.ShowDialog();
                            }
                            else
                            {
                                MessageBox.Show("已取消新增");
                            }
                        }
                        else
                        {
                            MessageBox.Show("預計取貨日 需大於 今天的日期");
                        }
                                                
                    }
                    else
                    {
                        MessageBox.Show("產品、數量、取貨方式及預計取貨日 皆為必填欄位");
                    }
                }
                else
                {
                    MessageBox.Show("您尚未選擇客戶");
                }
            }
        }

        private void btn訂單管理_Click(object sender, EventArgs e)
        {
            
        }

        private void btn回主頁_Click(object sender, EventArgs e)
        {
            functionList2 functionList2 = new functionList2();
            this.Hide();
            functionList2.ShowDialog();
        }

        private void btn關閉_Click(object sender, EventArgs e)
        {
            System.Environment.Exit(System.Environment.ExitCode);//強制關閉程式
        }
    }
}
