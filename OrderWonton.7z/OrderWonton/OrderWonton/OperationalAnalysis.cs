﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace OrderWonton
{
    public partial class OperationalAnalysis : Form
    {
        public OperationalAnalysis()
        {
            InitializeComponent();
        }

        private void OperationalAnalysis_Load(object sender, EventArgs e)
        {
            
            using (SqlConnection con = new SqlConnection(Global.scsb))
            {
                //產品分析的年份
                string strSQL = "select distinct year(o_date) from orders";
                SqlDataAdapter sqlDataAdapter = new SqlDataAdapter(strSQL, con);
                DataSet ds1 = new DataSet();
                sqlDataAdapter.Fill(ds1, "year");

                for (int i = 0; i < ds1.Tables["year"].Rows.Count; i += 1)
                {
                    cbox年份.Items.Add(ds1.Tables["year"].Rows[i][0]);
                }

                //時間分析的年份
                string strSQL2 = "select distinct year(o_date) from orders";
                SqlDataAdapter sqlDataAdapter2 = new SqlDataAdapter(strSQL2, con);
                DataSet ds2 = new DataSet();
                sqlDataAdapter2.Fill(ds2, "year");

                for (int i = 0; i < ds2.Tables["year"].Rows.Count; i += 1)
                {
                    cbox年份2.Items.Add(ds2.Tables["year"].Rows[i][0]);
                }

                //顧客貢獻度的年份
                string strSQL4 = "select distinct year(o_date) from orders";
                SqlDataAdapter sqlDataAdapter4 = new SqlDataAdapter(strSQL4, con);
                DataSet ds4 = new DataSet();
                sqlDataAdapter4.Fill(ds4, "year");

                for (int i = 0; i < ds4.Tables["year"].Rows.Count; i += 1)
                {
                    cbox年份3.Items.Add(ds4.Tables["year"].Rows[i][0]);
                }


                //選擇產品
                string strSQL3 = "select p_name from products";
                SqlDataAdapter sda3 = new SqlDataAdapter(strSQL3, con);
                DataSet ds3 = new DataSet();
                sda3.Fill(ds3, "productName");

                for (int i = 0; i < ds3.Tables["productName"].Rows.Count; i++)
                {
                    cbox產品.Items.Add(ds3.Tables["productName"].Rows[i][0]);
                }

            }
        }
        //產品分析的年份改變時
        private void cbox年份_SelectedIndexChanged(object sender, EventArgs e)
        {
            cbox月份.Items.Clear();
            using (SqlConnection con = new SqlConnection(Global.scsb))
            {
                //月份
                string strSQL2 = "select distinct month(o_date) from orders where year(o_date)='" + cbox年份.Text + "'";
                SqlDataAdapter sqlDataAdapter2 = new SqlDataAdapter(strSQL2, con);
                DataSet ds2 = new DataSet();
                sqlDataAdapter2.Fill(ds2, "month");

                for (int i = 0; i < ds2.Tables["month"].Rows.Count; i += 1)
                {
                    cbox月份.Items.Add(ds2.Tables["month"].Rows[i][0]);
                }
            }
        }

        //顧客分析的年份改變時
        private void cbox年份3_SelectedIndexChanged(object sender, EventArgs e)
        {
            cbox月份3.Items.Clear();

            using (SqlConnection con = new SqlConnection(Global.scsb))
            {
                
                string strSQL2 = "select distinct month(o_date) from orders where year(o_date)='" + cbox年份3.Text + "'";
                SqlDataAdapter sqlDataAdapter2 = new SqlDataAdapter(strSQL2, con);
                DataSet ds2 = new DataSet();
                sqlDataAdapter2.Fill(ds2, "month");

                for (int i = 0; i < ds2.Tables["month"].Rows.Count; i += 1)
                {
                    cbox月份3.Items.Add(ds2.Tables["month"].Rows[i][0]);
                }
            }

        }


        private void btn取得分析結果_Click(object sender, EventArgs e)
        {
            tb品名.Text = cbox產品.Text;
            using (SqlConnection con = new SqlConnection(Global.scsb))
            {

                if (cbox年份.SelectedIndex >= 0 && cbox月份.SelectedIndex>=0)
                {
                    string strSQL3 = "select sum(o_qty) from orders o inner join products p on (o.p_id=p.p_id) where p.p_name = '" + cbox產品.Text + "' and year(o.o_date)='" + cbox年份.Text + "' and month(o.o_date)='" + cbox月份.Text + "' and o.o_paystatus='已付款' ";
                    SqlDataAdapter sqlDataAdapter3 = new SqlDataAdapter(strSQL3, con);
                    DataSet ds3 = new DataSet();
                    sqlDataAdapter3.Fill(ds3, "Qty");
                    tb數量.Text = ds3.Tables["Qty"].Rows[0][0].ToString();

                    string strSQL4 = "select sum(o_totalprice) from orders o inner join products p on (o.p_id=p.p_id) where p.p_name = '" + cbox產品.Text + "' and year(o.o_date)='" + cbox年份.Text + "' and month(o.o_date)='" + cbox月份.Text + "' and o.o_paystatus='已付款' ";
                    SqlDataAdapter sqlDataAdapter4 = new SqlDataAdapter(strSQL4, con);                    
                    sqlDataAdapter4.Fill(ds3, "total");
                    tb營業額.ForeColor = Color.Red;
                    tb營業額.Text = ds3.Tables["total"].Rows[0][0].ToString();

                    if (tb數量.Text == "")
                    {
                        MessageBox.Show("查無資料");
                    }
                }
                else if (cbox年份.SelectedIndex >= 0 && cbox月份.SelectedIndex<0)
                {
                    string strSQL3 = "select sum(o_qty) from orders o inner join products p on (o.p_id=p.p_id) where p.p_name = '" + cbox產品.Text + "' and year(o.o_date)='" + cbox年份.Text + "' and o.o_paystatus='已付款' ";
                    SqlDataAdapter sqlDataAdapter3 = new SqlDataAdapter(strSQL3, con);
                    DataSet ds3 = new DataSet();
                    sqlDataAdapter3.Fill(ds3, "Qty");
                    tb數量.Text = ds3.Tables["Qty"].Rows[0][0].ToString();

                    string strSQL4 = "select sum(o_totalprice) from orders o inner join products p on (o.p_id=p.p_id) where p.p_name = '" + cbox產品.Text + "' and year(o.o_date)='" + cbox年份.Text + "' and o.o_paystatus='已付款'";
                    SqlDataAdapter sqlDataAdapter4 = new SqlDataAdapter(strSQL4, con);
                    sqlDataAdapter4.Fill(ds3, "total");
                    tb營業額.ForeColor = Color.Red;
                    tb營業額.Text = ds3.Tables["total"].Rows[0][0].ToString();

                    if (tb數量.Text == "")
                    {
                        MessageBox.Show("查無資料");
                    }
                }
                else
                {
                    MessageBox.Show("請選擇欲篩選的\"產品\"與\"時間\"");
                }

                
                
            }
        }

        private void btn重新整理_Click(object sender, EventArgs e)
        {
            OperationalAnalysis oa = new OperationalAnalysis();
            this.Hide();
            oa.ShowDialog();
        }

        

        private void btn取得分析結果2_Click(object sender, EventArgs e)
        {
            using (SqlConnection con = new SqlConnection(Global.scsb))
            {
                if (cbox年份2.SelectedIndex>=0)
                {
                    string strSQL = "select distinct month(o_date) as 月份,sum(o_totalprice) as 營業額 from orders where year(o_date)='" + cbox年份2.Text + "' and o_paystatus='已付款' group by o_date,o_totalprice";
                    SqlCommand cmd = new SqlCommand(strSQL, con);
                    cmd.CommandType = CommandType.Text;

                    chart時間分析.DataSource = cmd; // 以 SqlCommand 物件作為圖表的資料來源

                    // 設定數列的 X 及 Y 軸
                    chart時間分析.Series["營業額"].XValueMember = "月份";
                    chart時間分析.Series["營業額"].YValueMembers = "營業額";
                    //chart時間分析.Series["營業額"].IsValueShownAsLabel = true;  //在每個數列上方是否需顯示該數數之數值

                    chart時間分析.DataBind(); //再將圖表繫結至資料來源
                }
                else
                {
                    MessageBox.Show("請選擇年份");
                }
                

            }

            
        }

        //顧客貢獻度的SQL指令有誤 (6/23)
        private void btn取得分析結果3_Click(object sender, EventArgs e)
        {
            using (SqlConnection con = new SqlConnection(Global.scsb))
            {
                if (cbox年份3.SelectedIndex<0 && cbox月份3.SelectedIndex<0)
                {
                    MessageBox.Show("請選擇篩選方式");
                }                
                else if(cbox年份3.SelectedIndex>=0 && cbox月份3.SelectedIndex < 0)
                {   //只篩選年分
                    string strSQL = "select  c.c_id as ID ,c.c_nickname as 顧客,sum(o_totalprice) as 營業額 from orders o inner join customers c on (o.c_id=c.c_id) where year(o_date)='" + cbox年份3.Text + "' and o.o_paystatus='已付款' group by c.c_id,c.c_nickname";
                    SqlCommand cmd = new SqlCommand(strSQL, con);
                    cmd.CommandType = CommandType.Text;

                    chart顧客貢獻度.DataSource = cmd; // 以 SqlCommand 物件作為圖表的資料來源

                    // 設定數列的 X 及 Y 軸
                    chart顧客貢獻度.Series["顧客"].XValueMember = "顧客";
                    chart顧客貢獻度.Series["顧客"].YValueMembers = "營業額";
                    //chart時間分析.Series["營業額"].IsValueShownAsLabel = true;  //在每個數列上方是否需顯示該數數之數值

                    chart顧客貢獻度.DataBind(); //再將圖表繫結至資料來源

                    //顯示VIP
                    string strSQL2 = "select top(1) c.c_id as ID ,c.c_name as 顧客,sum(o_totalprice) as 營業額 from orders o inner join customers c on (o.c_id=c.c_id) where year(o_date)='" + cbox年份3.Text + "' and o.o_paystatus='已付款' group by c.c_id,c.c_name order by 3 desc";
                    SqlDataAdapter sda = new SqlDataAdapter(strSQL2, con);
                    DataSet ds = new DataSet();
                    sda.Fill(ds, "VIP");
                    lblVIP.Text = ds.Tables["VIP"].Rows[0][1].ToString();

                }
                else
                {   //篩選年份+月份
                    string strSQL = "select  c.c_id as ID ,c.c_nickname as 顧客,sum(o_totalprice) as 營業額 from orders o inner join customers c on (o.c_id=c.c_id) where year(o_date)='" + cbox年份3.Text + "' and month(o_date)='" + cbox月份3.Text + "' and o.o_paystatus='已付款' group by c.c_id,c.c_nickname,o_totalprice ";
                    SqlCommand cmd = new SqlCommand(strSQL, con);
                    cmd.CommandType = CommandType.Text;

                    chart顧客貢獻度.DataSource = cmd; // 以 SqlCommand 物件作為圖表的資料來源

                    // 設定數列的 X 及 Y 軸
                    chart顧客貢獻度.Series["顧客"].XValueMember = "顧客";
                    chart顧客貢獻度.Series["顧客"].YValueMembers = "營業額";
                    //chart時間分析.Series["營業額"].IsValueShownAsLabel = true;  //在每個數列上方是否需顯示該數數之數值

                    chart顧客貢獻度.DataBind(); //再將圖表繫結至資料來源

                    //顯示VIP
                    string strSQL2 = "select top(1) c.c_id as ID ,c.c_name as 顧客,sum(o_totalprice) as 營業額 from orders o inner join customers c on (o.c_id=c.c_id) where year(o_date)='" + cbox年份3.Text + "'and month(o_date)='" + cbox月份3.Text + "' and o.o_paystatus='已付款' group by c.c_id,c.c_name order by 3 desc";
                    SqlDataAdapter sda = new SqlDataAdapter(strSQL2, con);
                    DataSet ds = new DataSet();
                    sda.Fill(ds, "VIP");
                    lblVIP.Text = ds.Tables["VIP"].Rows[0][1].ToString();

                }                              

            }
        }

        private void btn提示_Click(object sender, EventArgs e)
        {
            MessageBox.Show("本分析結果依訂單管理系統中 \"已付款\" 的資料做統計","提示",MessageBoxButtons.OK,MessageBoxIcon.Information);
        }

        private void btn回主頁_Click(object sender, EventArgs e)
        {
            functionList2 functionList2 = new functionList2();
            this.Hide();
            functionList2.ShowDialog();
        }

        private void btn關閉_Click(object sender, EventArgs e)
        {
            System.Environment.Exit(System.Environment.ExitCode);//強制關閉程式
        }
    }
}
